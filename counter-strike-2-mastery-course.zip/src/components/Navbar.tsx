/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Target, MessageSquare, LogOut, Award, Sparkles, LogIn } from 'lucide-react';
import { StudentEnrollment } from '../types';

interface NavbarProps {
  activeView: string;
  setActiveView: (view: string) => void;
  enrollment: StudentEnrollment | null;
  onLogout: () => void;
  onSimulateSandbox: () => void;
  onOpenCheckout: (tier: 'standard' | 'pro') => void;
}

export default function Navbar({
  activeView,
  setActiveView,
  enrollment,
  onLogout,
  onSimulateSandbox,
  onOpenCheckout
}: NavbarProps) {
  
  const navItems = [
    { name: 'Home', view: 'home' },
    { name: 'Curriculum', view: 'curriculum' },
    { name: 'Coaches', view: 'coaches' },
    { name: 'Pricing', view: 'pricing' },
    { name: 'FAQ', view: 'faq' },
    { name: 'Support', view: 'contact' }
  ];

  return (
    <nav className="w-full bg-cs-dark/95 backdrop-blur-md border-b border-cs-border sticky top-0 z-40 transition-all duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          
          {/* Logo Brand */}
          <div 
            onClick={() => setActiveView('home')} 
            className="flex items-center gap-2.5 cursor-pointer group"
            id="navbar-logo"
          >
            <div className="w-10 h-10 rounded-lg bg-cs-orange flex items-center justify-center text-white font-black text-2xl tracking-tighter shadow-lg group-hover:scale-105 transition-transform duration-200">
              CS
            </div>
            <div>
              <div className="font-display font-black text-white text-base leading-none tracking-widest uppercase flex items-center gap-1">
                MASTERY <span className="text-cs-orange text-[10px] font-mono tracking-tighter bg-cs-orange/10 px-1 border border-cs-orange/20 rounded">HUB</span>
              </div>
              <span className="text-[10px] font-mono text-cs-gray leading-none uppercase">Counter-Strike 2 Academy</span>
            </div>
          </div>

          {/* Desktop Navigation Link Cluster */}
          <div className="hidden lg:flex items-center gap-1">
            {navItems.map((item) => {
              const isActive = activeView === item.view;
              return (
                <button
                  key={item.view}
                  onClick={() => setActiveView(item.view)}
                  className={`px-4 py-2 text-xs font-mono uppercase font-bold tracking-wider rounded-md transition-all duration-150 cursor-pointer ${
                    isActive 
                      ? 'text-cs-orange bg-cs-orange/5' 
                      : 'text-cs-gray hover:text-white hover:bg-cs-surface/40'
                  }`}
                  id={`nav-link-${item.view}`}
                >
                  {item.name}
                </button>
              );
            })}
          </div>

          {/* User Sign-In/Enrollment Actions */}
          <div className="flex items-center gap-3">
            
            {enrollment ? (
              <>
                {/* Enrolled Status */}
                <button
                  onClick={() => setActiveView('student-portal')}
                  className={`px-4 py-2 rounded-lg font-mono text-xs uppercase font-bold tracking-wider cursor-pointer flex items-center gap-2 transition-all duration-200 ${
                    activeView === 'student-portal'
                      ? 'bg-cs-orange text-white shadow'
                      : 'bg-cs-surface border border-cs-border text-cs-orange hover:text-white hover:bg-cs-surface-light'
                  }`}
                  id="nav-student-portal"
                >
                  <Award size={14} className="animate-pulse" />
                  {enrollment.tier === 'pro' ? '♛ Pro Room' : '✦ Student Desk'}
                </button>

                {/* Logout */}
                <button
                  onClick={onLogout}
                  title="Logout Simulator"
                  className="p-2 bg-cs-surface hover:bg-red-950/20 border border-cs-border rounded-lg text-cs-gray hover:text-red-400 transition-colors cursor-pointer"
                  id="nav-logout-btn"
                >
                  <LogOut size={16} />
                </button>
              </>
            ) : (
              <>
                {/* Instant Sandbox Starter */}
                <button
                  onClick={onSimulateSandbox}
                  className="hidden sm:flex px-4 py-2 bg-cs-surface hover:bg-cs-surface-light border border-cs-border text-cs-yellow hover:text-white font-mono text-[10px] uppercase font-bold tracking-wider rounded-lg transition-all cursor-pointer items-center gap-1"
                  id="nav-sandbox-btn"
                  title="Instantly bypass transaction layer to review the core workspace"
                >
                  <Sparkles size={12} className="text-cs-yellow animate-bounce" />
                  Sandbox Demo
                </button>

                {/* Main purchase CTA */}
                <button
                  onClick={() => onOpenCheckout('standard')}
                  className="px-4 py-2.5 bg-cs-orange text-white font-display font-extrabold uppercase text-xs tracking-wider rounded-lg shadow-md hover:scale-103 active:scale-97 transition-all cursor-pointer glow-btn flex items-center gap-1.5"
                  id="nav-enroll-button"
                >
                  <Target size={14} />
                  Enlist — $49.99
                </button>
              </>
            )}

          </div>

        </div>
      </div>
      
      {/* Mobile navigation notification helper */}
      <div className="lg:hidden bg-cs-surface-light border-y border-cs-border px-4 py-1.5 overflow-x-auto whitespace-nowrap scrollbar-none flex gap-3 text-[10px] font-mono text-cs-gray">
        {navItems.map((item) => {
          const isActive = activeView === item.view;
          return (
            <button
              key={item.view}
              onClick={() => setActiveView(item.view)}
              className={`uppercase font-bold shrink-0 py-0.5 px-2 rounded-sm ${isActive ? 'text-cs-orange bg-cs-orange/10' : ''}`}
            >
              {item.name}
            </button>
          );
        })}
        {enrollment && (
          <button
            onClick={() => setActiveView('student-portal')}
            className={`uppercase font-bold shrink-0 text-cs-yellow ${activeView === 'student-portal' ? 'bg-cs-yellow/10 px-2 rounded-sm' : ''}`}
          >
            ★ Student Classroom
          </button>
        )}
      </div>
    </nav>
  );
}
