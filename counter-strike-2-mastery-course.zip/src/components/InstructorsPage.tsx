/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Shield, Target, Award, Users, Crosshair, Star } from 'lucide-react';
import { instructorsData } from '../data';

interface InstructorsPageProps {
  onOpenCheckout: (tier: 'standard' | 'pro') => void;
}

export default function InstructorsPage({ onOpenCheckout }: InstructorsPageProps) {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-16 animate-fade-in" id="coaches-root">
      
      {/* Roster Header */}
      <div className="text-center space-y-3 max-w-2xl mx-auto">
        <span className="text-xs font-mono text-cs-orange font-bold uppercase tracking-widest">[INSTRUCTOR DIRECTIVE]</span>
        <h1 className="text-4xl md:text-5xl font-display font-black text-white uppercase tracking-wide">
          VERIFIED ESPORTS COACHES
        </h1>
        <p className="text-sm text-cs-gray leading-relaxed font-sans">
          Learn from former competitive players, professional analysts, and Faceit Level 10 stars. We don't preach theory — we drill functional habits based on real statistics.
        </p>
      </div>

      {/* Roster profiles */}
      <div className="space-y-12">
        {instructorsData.map((coach) => (
          <div key={coach.id} className="bg-cs-surface border border-cs-border rounded-2xl p-6 md:p-10 flex flex-col lg:flex-row gap-10 hover:border-cs-orange/30 transition-all duration-300 relative overflow-hidden shadow-xl" id={`coach-profile-${coach.id}`}>
            
            {/* Visual Column */}
            <div className="lg:w-80 shrink-0 space-y-4">
              <div className="aspect-square rounded-xl overflow-hidden border border-cs-border relative">
                <img 
                  src={coach.avatar} 
                  alt={coach.name} 
                  className="w-full h-full object-cover filter brightness-90 pointer-events-none"
                  referrerPolicy="no-referrer"
                />
                
                {/* Floating Faceit Pill */}
                <div className="absolute top-4 right-4 bg-cs-orange text-white font-mono text-[10px] uppercase font-bold px-2 py-1 rounded shadow-lg border border-cs-border/60">
                  LEVEL {coach.stats.faceitLevel} COACH
                </div>
              </div>

              {/* Stats Card metrics for esports credibility */}
              <div className="bg-cs-dark border border-cs-border/80 rounded-lg p-4 font-mono space-y-3 shadow-inner">
                <div className="text-center text-xs text-white uppercase font-bold border-b border-cs-border/40 pb-2">
                  VERIFIED STATS PORTAL
                </div>
                
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="bg-cs-surface p-2 rounded text-center">
                    <span className="text-[8px] text-cs-gray block">FACEIT ELO</span>
                    <span className="text-white font-bold">{coach.stats.elo} ELO</span>
                  </div>
                  <div className="bg-cs-surface p-2 rounded text-center">
                    <span className="text-[8px] text-cs-gray block">WIN RATE</span>
                    <span className="text-cs-green font-bold">{coach.stats.winRate}</span>
                  </div>
                  <div className="bg-cs-surface p-2 rounded text-center">
                    <span className="text-[8px] text-cs-gray block">AVG K/D</span>
                    <span className="text-cs-yellow font-bold">{coach.stats.averageKDR}</span>
                  </div>
                  <div className="bg-cs-surface p-2 rounded text-center">
                    <span className="text-[8px] text-cs-gray block">COACH AGE</span>
                    <span className="text-white font-bold">{coach.yearsOfExp} YRS</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Strategic Bio Info */}
            <div className="flex-1 space-y-6 flex flex-col justify-between">
              <div className="space-y-4">
                <div className="space-y-1">
                  <span className="text-xs uppercase font-mono tracking-wider text-cs-orange font-bold">TACTICAL SPECIALTY: {coach.specialty}</span>
                  <h3 className="text-2xl md:text-3xl font-display font-black text-white uppercase tracking-wide">
                    {coach.name} <span className="text-cs-gray text-xl">({coach.nickname})</span>
                  </h3>
                  <p className="text-xs text-cs-yellow uppercase font-mono tracking-widest font-bold">
                    {coach.role}
                  </p>
                </div>

                <p className="text-sm text-cs-gray leading-relaxed font-sans text-slate-300">
                  {coach.bio}
                </p>

                <blockquote className="border-l-2 border-cs-orange pl-4 text-xs italic text-slate-400 max-w-xl leading-relaxed bg-cs-dark/20 py-1.5 rounded-r">
                  "{coach.coachQuote}"
                </blockquote>
              </div>

              {/* Roster of coached achievements */}
              <div className="pt-6 border-t border-cs-border/40 space-y-4">
                <h5 className="font-display font-extrabold text-xs text-white uppercase tracking-wider flex items-center gap-1.5">
                  <Crosshair size={14} className="text-cs-orange" /> Verified Esports Achievements & Loggings
                </h5>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs font-sans text-cs-gray leading-relaxed">
                  <div className="flex items-start gap-2">
                    <span className="text-cs-orange font-mono font-bold shrink-0">◇</span>
                    <span>Instructed 4 competitive players into Tier-2 European rosters.</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <span className="text-cs-orange font-mono font-bold shrink-0">◇</span>
                    <span>Compiled over 14,000 hours of physical CS gameplay analytics.</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <span className="text-cs-orange font-mono font-bold shrink-0">◇</span>
                    <span>Authored the 'Kinetic Recoil Calibration Ruleset' used globally.</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <span className="text-cs-orange font-mono font-bold shrink-0">◇</span>
                    <span>Administered over 450+ 1-on-1 gameplay demo diagnoses in CS2.</span>
                  </div>
                </div>
              </div>

            </div>

          </div>
        ))}
      </div>

    </div>
  );
}
