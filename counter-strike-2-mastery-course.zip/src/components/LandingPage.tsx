/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Target, Shield, Award, Sparkles, Check, ArrowRight, X, 
  Flame, Skull, Volume2, ShieldAlert, Zap, Users, Play, Star
} from 'lucide-react';
import { Testimonial, Instructor, Week } from '../types';
import { testimonialsData, instructorsData, weeksData } from '../data';

interface LandingPageProps {
  onOpenCheckout: (tier: 'standard' | 'pro') => void;
  onSimulateSandbox: () => void;
  setActiveView: (view: string) => void;
}

export default function LandingPage({
  onOpenCheckout,
  onSimulateSandbox,
  setActiveView
}: LandingPageProps) {
  
  // Real-time simulated countdown timer for urgency
  const [timeLeft, setTimeLeft] = useState({ hours: 1, minutes: 42, seconds: 18 });

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 };
        } else if (prev.minutes > 0) {
          return { ...prev, minutes: prev.minutes - 1, seconds: 59 };
        } else if (prev.hours > 0) {
          return { hours: prev.hours - 1, minutes: 59, seconds: 59 };
        } else {
          // Reset timer to keep demo looping
          return { hours: 2, minutes: 15, seconds: 0 };
        }
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Format countdown output helper
  const formatTime = (t: number) => t.toString().padStart(2, '0');

  // Pain Points Mock Data
  const painPoints = [
    {
      icon: <Skull className="text-red-500" size={32} />,
      title: "Hardstuck in Silver Hell?",
      desc: "Tired of taking three steps forward only to lose two matches in a row because your team plays without coordination? It isn't just your luck — you lack a structured improvement routine."
    },
    {
      icon: <ShieldAlert className="text-red-500" size={32} />,
      title: "Toxic, Silent Lobbies?",
      desc: "Sick of queueing up solo only to find teammates who scream into the microphone, buy every round without thinking, and blame you for their entry deaths? Learn how to navigate solo queue structures."
    },
    {
      icon: <Zap className="text-red-500" size={32} />,
      title: "Inconsistent Aim Performance?",
      desc: "One game you drop 30 kills and feel like s1mple, the next match you struggle to land a single spray and hit for 99 in 4. Learn how to standardize your sensitivity, crosshair, and biomechanics."
    }
  ];

  // Map representation data for visuals
  const csMaps = [
    { name: "Mirage", role: "Active", bg: "https://images.unsplash.com/photo-1542751371-adc38448a05e?q=80&w=400&h=250&fit=crop" },
    { name: "Dust II", role: "Active", bg: "https://images.unsplash.com/photo-1511512578047-dfb367046420?q=80&w=400&h=250&fit=crop" },
    { name: "Inferno", role: "Active", bg: "https://images.unsplash.com/photo-1612287230202-1bf1d85d1bdf?q=80&w=400&h=250&fit=crop" }
  ];

  const skillGrid = [
    { title: "Surgical Aim Calibration", desc: "True physical sensitivity optimization, eDPI standardization, and spray patterns mechanical memory.", category: "aim" },
    { title: "High-Tier Fluid Movement", desc: "Perfect counter-strafing, air strafing, shoulder peek baits, and latency peek manipulation.", category: "movement" },
    { title: "Meta Utility Executes", desc: "Pixel perfect smokes, pop-flashes, and molotov lineups for the current active competitive map pool.", category: "utility" },
    { title: "Dynamic Economy Control", desc: "Read opponent spendings, control force buying timing, and structural team economic strategies.", category: "economy" },
    { title: "Clinical Match Calling", desc: "Structured, calm team calling codes. Eliminating toxic noise and panic transmissions mid-round.", category: "teamplay" },
    { title: "Neuro Tilt Reset", desc: "A robust neurological framing framework to eliminate emotional blockages and solo queue stress.", category: "mindset" }
  ];

  return (
    <div className="space-y-24 pb-20 animate-fade-in" id="landing-page-root">
      
      {/* 1. HERO BANNER LANDING SECTION */}
      <section className="relative min-h-[85vh] flex items-center justify-center pt-12 overflow-hidden border-b border-cs-border bg-gradient-to-b from-cs-dark via-cs-surface/40 to-cs-dark">
        {/* Decorative Grid Network & Overlay */}
        <div className="absolute inset-0 scanline-overlay opacity-5 pointer-events-none"></div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[400px] bg-cs-orange/5 rounded-full filter blur-[100px] pointer-events-none"></div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10 space-y-8">
          
          {/* Top micro badge */}
          <div className="inline-flex items-center gap-2 bg-cs-orange/10 border border-cs-orange/20 px-3 py-1.5 rounded-full text-xs font-mono text-cs-orange font-bold uppercase tracking-widest animate-pulse max-w-max mx-auto">
            <Sparkles size={12} /> Live CS2 Enrollment Cycle Open
          </div>

          {/* Hero text headlines */}
          <div className="space-y-4 max-w-4xl mx-auto">
            <h1 className="text-5xl sm:text-6xl md:text-8xl font-display font-black tracking-tight text-white uppercase italic leading-none">
              STOP LOSING.<br />
              <span className="text-gradient bg-clip-text bg-gradient-to-r from-cs-orange to-cs-yellow text-transparent">START DOMINATING.</span>
            </h1>
            <p className="text-base sm:text-xl text-cs-gray font-normal max-w-2xl mx-auto leading-relaxed">
              Ditch the generic YouTube tutorials. Master Counter-Strike 2 with our structured, 4-week university-grade competitive curriculum. Retrain mouse kinetics, land lineups, and secure Faceit Level 10.
            </p>
          </div>

          {/* CTA Group */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
            <button
              onClick={() => onOpenCheckout('standard')}
              className="w-full sm:w-auto px-8 py-4 bg-cs-orange text-white font-display font-extrabold uppercase text-lg tracking-wider hover:bg-cs-orange/90 active:scale-95 transition-all rounded-lg shadow-xl cursor-pointer glow-btn flex items-center justify-center gap-2"
              id="hero-cta"
            >
              Enlist Now for $49.99
              <ArrowRight size={18} />
            </button>
            
            <button
              onClick={onSimulateSandbox}
              className="w-full sm:w-auto px-8 py-4 bg-cs-surface border border-cs-border hover:bg-cs-surface-light text-cs-yellow font-mono text-xs uppercase font-bold tracking-wider rounded-lg transition-all cursor-pointer flex items-center justify-center gap-2"
              id="hero-sandbox-cta"
              title="Fast pass straight into Sandbox state"
            >
              Explore Sandbox Classroom
            </button>
          </div>

          {/* Core Trust Row indicators */}
          <div className="pt-8 border-t border-cs-border/30 max-w-3xl mx-auto">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-6 text-center">
              <div>
                <div className="text-xl sm:text-2xl font-display font-black text-white">2,480+</div>
                <div className="text-[10px] font-mono text-cs-gray uppercase tracking-wider">Students Enrolled</div>
              </div>
              <div>
                <div className="text-xl sm:text-2xl font-display font-black text-cs-yellow flex items-center justify-center gap-1">
                  <span>4.95</span>
                  <Star size={14} className="fill-cs-yellow text-cs-yellow mt-0.5" />
                </div>
                <div className="text-[10px] font-mono text-cs-gray uppercase tracking-wider">Course Rating</div>
              </div>
              <div>
                <div className="text-xl sm:text-2xl font-display font-black text-white">30 DAYS</div>
                <div className="text-[10px] font-mono text-cs-gray uppercase tracking-wider">Refund Guarantee</div>
              </div>
              <div>
                <div className="text-xl sm:text-2xl font-display font-black text-cs-green uppercase">94.2%</div>
                <div className="text-[10px] font-mono text-cs-gray uppercase tracking-wider">Rank-Up SUCCESS</div>
              </div>
            </div>
          </div>

        </div>
      </section>

      {/* 2. FRUSTRATIONS / HOOK SECTION */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        <div className="text-center space-y-2 max-w-2xl mx-auto">
          <span className="text-xs font-mono text-cs-orange font-bold uppercase tracking-widest">[RECONNAISSANCE]</span>
          <h2 className="text-3xl sm:text-4xl font-display font-black text-white uppercase tracking-wide">
            DOES COMPETITIVE CS2 FEEL LIKE A COIN FLIP?
          </h2>
          <p className="text-sm text-cs-gray leading-relaxed font-normal">
            YouTube advice can actually stunt your growth. If you are drilling aiming guides without stabilizing crosshair recovery rules or counter-strafing bounds, you are cementing bad mechanics.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {painPoints.map((point, idx) => (
            <div 
              key={idx} 
              className="bg-cs-surface border border-cs-border rounded-xl p-6 md:p-8 space-y-4 hover:-translate-y-1 transition-transform duration-300"
            >
              <div className="w-12 h-12 rounded-lg bg-red-950/20 border border-red-500/20 flex items-center justify-center shrink-0">
                {point.icon}
              </div>
              <h4 className="font-display font-black text-base text-white uppercase tracking-wider leading-tight">
                {point.title}
              </h4>
              <p className="text-xs text-cs-gray leading-relaxed text-slate-300">
                {point.desc}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* 3. SKILLS GRID / CORE CURRICULUM SECTORS */}
      <section className="bg-cs-surface border-y border-cs-border py-20 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          
          <div className="text-center space-y-2 max-w-2xl mx-auto">
            <span className="text-xs font-mono text-cs-orange font-bold uppercase tracking-widest">[SYLLABUS STRATEGY]</span>
            <h2 className="text-3xl sm:text-4xl font-display font-black text-white uppercase tracking-wide">
              THE 6 PILLARS OF CS2 MASTERY
            </h2>
            <p className="text-xs text-cs-gray leading-relaxed">
              We break elite competitive game logic into precise, digestible physical models.
              No secrets. Just physics, mathematics, and tactical geometry.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {skillGrid.map((skill, idx) => (
              <div 
                key={idx} 
                className="bg-cs-dark border border-cs-border rounded-xl p-6 space-y-3 shadow-md hover:border-cs-orange/40 transition-all group"
              >
                <div className="flex justify-between items-center">
                  <span className="text-[10px] font-mono text-cs-orange font-bold capitalize">
                    sector_0{idx + 1}
                  </span>
                  <div className="w-2 h-2 rounded-full bg-cs-border group-hover:bg-cs-orange transition-colors"></div>
                </div>
                <h4 className="font-display font-black text-base uppercase tracking-wider text-white">
                  {skill.title}
                </h4>
                <p className="text-xs text-cs-gray leading-relaxed text-slate-300">
                  {skill.desc}
                </p>
              </div>
            ))}
          </div>

        </div>
      </section>

      {/* 4. CHRONOLOGICAL WEEKLY ACCORDION PREVIEW */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        <div className="text-center space-y-2 max-w-2xl mx-auto">
          <span className="text-xs font-mono text-cs-orange font-bold uppercase tracking-widest">[TIMELINE METHODOLOGY]</span>
          <h2 className="text-3xl sm:text-4xl font-display font-black text-white uppercase tracking-wide">
            4-WEEK PERFORMANCE DRILL LOOP
          </h2>
          <p className="text-xs text-cs-gray">
            A week-by-week progressive training sequence meticulously structured to reintroduce habits, eliminate spatial flaws, and unlock advanced ranked systems.
          </p>
        </div>

        <div className="space-y-6 max-w-4xl mx-auto">
          {weeksData.map((week, idx) => (
            <div 
              key={week.weekNumber} 
              className="bg-cs-surface border border-cs-border rounded-xl p-6 md:p-8 flex flex-col md:flex-row gap-6 hover:border-cs-orange/30 transition-all duration-300 relative group"
            >
              <div className="md:w-32 shrink-0">
                <span className="text-[10px] font-mono text-cs-orange font-bold block uppercase tracking-widest">MODULE 0{week.weekNumber}</span>
                <div className="text-4xl font-display font-black tracking-tighter text-white mt-1 uppercase italic">
                  WEEK 0{week.weekNumber}
                </div>
              </div>

              <div className="space-y-3 min-w-0 flex-1">
                <h4 className="font-display font-black text-lg text-white uppercase tracking-wider leading-none">
                  {week.title}
                </h4>
                <p className="text-xs text-cs-gray leading-relaxed text-slate-300 font-sans">
                  {week.description}
                </p>
                
                {/* Micro lessons stack preview */}
                <div className="pt-3 border-t border-cs-border/50 flex flex-wrap gap-x-4 gap-y-2 text-[10px] font-mono text-cs-gray">
                  {week.lessons.slice(0, 3).map((lesson, curIdx) => (
                    <span key={lesson.id} className="flex items-center gap-1.5 bg-cs-dark border border-cs-border px-2 py-1 rounded">
                      <Check size={10} className="text-cs-orange" /> {lesson.title.substring(0, 24)}...
                    </span>
                  ))}
                  {week.lessons.length > 3 && (
                    <span className="flex items-center gap-1.5 text-cs-yellow px-1 py-1 font-bold rounded">
                      +{week.lessons.length - 3} More Lectures
                    </span>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center">
          <button
            onClick={() => setActiveView('curriculum')}
            className="px-6 py-3 bg-cs-surface border border-cs-border hover:bg-cs-surface-light text-white text-xs font-mono uppercase font-bold tracking-widest rounded-lg transition-all cursor-pointer flex items-center gap-2 mx-auto"
            id="view-full-curriculum-btn"
          >
            Inspect Complete Lesson Index 
            <ArrowRight size={14} />
          </button>
        </div>
      </section>

      {/* 5. ESPORTS SOCIAL PROOF / RANK GAINS MATRIX */}
      <section className="bg-cs-surface border-y border-cs-border py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          
          <div className="text-center space-y-2 max-w-2xl mx-auto">
            <span className="text-xs font-mono text-cs-orange font-bold uppercase tracking-widest">[VALIDATION RESULTS]</span>
            <h2 className="text-3xl sm:text-4xl font-display font-black text-white uppercase tracking-wide">
              VERIFIED STUDENT RANK CONVERSIONS
            </h2>
            <p className="text-xs text-cs-gray">
              We track real historical telemetry. Witness actual rank transformations achieved by students utilizing our weekly manual worksheets.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonialsData.map((item) => (
              <div 
                key={item.id} 
                className="bg-cs-dark border border-cs-border rounded-xl p-6 md:p-8 space-y-5 flex flex-col justify-between shadow-lg"
              >
                <div className="space-y-4">
                  {/* Rank progression indicators */}
                  <div className="flex items-center justify-between border-b border-cs-border/40 pb-4">
                    <div className="text-center uppercase font-mono">
                      <div className="text-[8px] text-cs-gray">OLD RANK</div>
                      <div className="text-xs font-bold text-red-400 bg-red-950/20 border border-red-500/20 px-2 py-0.5 rounded mt-1">{item.oldRank}</div>
                    </div>
                    
                    <div className="text-cs-gray animate-pulse">➔</div>

                    <div className="text-center uppercase font-mono">
                      <div className="text-[8px] text-cs-yellow">NEW RANK</div>
                      <div className="text-xs font-bold text-cs-green bg-cs-green/10 border border-cs-green/20 px-2 py-0.5 rounded mt-1">{item.newRank}</div>
                    </div>
                  </div>

                  <p className="text-xs text-cs-gray leading-relaxed text-slate-300 italic">
                    "{item.text}"
                  </p>
                </div>

                <div className="flex items-center justify-between pt-4 border-t border-cs-border/40 font-mono text-[10px]">
                  <div>
                    <span className="text-white block font-bold font-sans">{item.name}</span>
                    <span className="text-cs-gray">Verified Cadet</span>
                  </div>
                  <span className="px-2 py-0.5 bg-cs-green/10 border border-cs-green/20 text-cs-green font-bold uppercase rounded-[3px] text-[8px] tracking-widest">
                    VERIFIED MATCH
                  </span>
                </div>
              </div>
            ))}
          </div>

        </div>
      </section>

      {/* 6. LEAD COACH SPOTLIGHT */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-cs-surface border border-cs-border rounded-2xl p-6 md:p-12 relative overflow-hidden">
          {/* Back glows */}
          <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-cs-orange/5 rounded-full filter blur-[100px] pointer-events-none"></div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center relative z-10">
            {/* Visual Column */}
            <div className="lg:col-span-5 relative group">
              <div className="aspect-square rounded-2xl overflow-hidden border border-cs-border">
                <img 
                  src={instructorsData[0].avatar} 
                  alt="Lead Coach Alex Vance" 
                  className="w-full h-full object-cover filter brightness-90 group-hover:scale-102 transition-transform duration-500 pointer-events-none"
                  referrerPolicy="no-referrer"
                />
              </div>
              
              {/* Floating Stat element */}
              <div className="absolute -bottom-4 -right-4 bg-cs-dark border border-cs-border rounded-lg p-4 font-mono text-center shadow-2xl">
                <div className="text-xs text-cs-gray uppercase">Faceit Tier</div>
                <div className="text-3xl font-display font-black text-cs-orange">LEVEL 10</div>
                <div className="text-[10px] text-cs-yellow uppercase font-bold tracking-widest mt-0.5">3,250 ELO</div>
              </div>
            </div>

            {/* Strategy Column */}
            <div className="lg:col-span-7 space-y-6">
              <div className="space-y-1.5">
                <span className="text-xs font-mono text-cs-orange font-bold uppercase tracking-widest">[LEAD STRATEGIST]</span>
                <h3 className="text-3xl sm:text-4xl font-display font-black text-white uppercase tracking-wider leading-none">
                  {instructorsData[0].name}
                </h3>
                <h5 className="font-mono text-xs text-cs-yellow uppercase tracking-wide">
                  {instructorsData[0].role} / {instructorsData[0].yearsOfExp} Years Competitive Edge
                </h5>
              </div>

              <p className="text-sm text-cs-gray leading-relaxed font-sans">
                {instructorsData[0].bio}
              </p>

              <div className="border-t border-b border-cs-border py-4 grid grid-cols-3 gap-4 text-center font-mono text-xs">
                <div>
                  <div className="text-lg font-display font-bold text-white uppercase">{instructorsData[0].stats.winRate}</div>
                  <span className="text-[9px] text-cs-gray uppercase">Pug Win rate</span>
                </div>
                <div>
                  <div className="text-lg font-display font-bold text-white uppercase">{instructorsData[0].stats.averageKDR}</div>
                  <span className="text-[9px] text-cs-gray uppercase">Average K/D</span>
                </div>
                <div>
                  <div className="text-lg font-display font-semibold text-cs-yellow uppercase">SPACED COOP</div>
                  <span className="text-[9px] text-cs-gray uppercase">Specialty Sector</span>
                </div>
              </div>

              <blockquote className="border-l-2 border-cs-orange pl-4 text-xs italic text-slate-300 leading-relaxed max-w-xl">
                "{instructorsData[0].coachQuote}"
              </blockquote>

              <div className="pt-2">
                <button
                  onClick={() => setActiveView('coaches')}
                  className="px-5 py-2.5 bg-cs-border hover:bg-cs-surface-light border border-transparent text-white text-xs font-mono uppercase font-bold tracking-wider rounded transition-all cursor-pointer"
                >
                  View Coached Rosters & Credentials
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 7. FINAL COUNTDOWN CALL TO ACTION */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-r from-cs-surface-light to-cs-dark border border-cs-border rounded-2xl p-8 md:p-12 text-center relative overflow-hidden shadow-2xl space-y-8">
          
          <div className="absolute inset-0 scanline-overlay opacity-5 pointer-events-none"></div>

          <div className="max-w-2xl mx-auto space-y-3">
            <span className="text-xs font-mono text-cs-orange font-bold uppercase tracking-widest">[IMMEDIATE ACTION PROTOCOL]</span>
            <h2 className="text-4xl sm:text-5xl font-display font-black text-white uppercase tracking-tight">
              REBUILD YOUR CS2 MECHANICS TODAY.
            </h2>
            <p className="text-sm text-cs-gray leading-relaxed max-w-lg mx-auto">
              Enrollments for this month are capped to maintain private server bandwiths. Unblock all 4-weeks of training materials instantly.
            </p>
          </div>

          {/* Countdown Clock */}
          <div className="flex items-center justify-center gap-4 max-w-sm mx-auto font-mono">
            <div className="bg-cs-dark border border-cs-border/80 px-4 py-3 rounded-lg w-20 shadow-inner">
              <div className="text-2xl font-bold text-cs-orange">{formatTime(timeLeft.hours)}</div>
              <span className="text-[8px] text-cs-gray uppercase">HOURS</span>
            </div>
            <span className="text-2xl text-cs-border font-bold">:</span>
            <div className="bg-cs-dark border border-cs-border/80 px-4 py-3 rounded-lg w-20 shadow-inner">
              <div className="text-2xl font-bold text-cs-orange">{formatTime(timeLeft.minutes)}</div>
              <span className="text-[8px] text-cs-gray uppercase">MINS</span>
            </div>
            <span className="text-2xl text-cs-border font-bold">:</span>
            <div className="bg-cs-dark border border-cs-border/80 px-4 py-3 rounded-lg w-20 shadow-inner">
              <div className="text-2xl font-bold text-cs-yellow">{formatTime(timeLeft.seconds)}</div>
              <span className="text-[8px] text-cs-gray uppercase">SECS</span>
            </div>
          </div>

          <div className="space-y-1">
            <div className="text-[10px] font-mono text-cs-orange font-semibold uppercase">LIMITED REGISTRATION SLOT OFFER</div>
            <div className="text-lg font-display text-white">Full 4-week Curriculum + Private Forums: <span className="text-cs-yellow font-black text-xl">$49.99</span></div>
          </div>

          <div className="pt-2">
            <button
              onClick={() => onOpenCheckout('standard')}
              className="px-10 py-4 bg-cs-orange text-white font-display font-black uppercase tracking-wider rounded-lg shadow-2xl hover:bg-cs-orange/90 scale-103 active:scale-97 transition-all cursor-pointer glow-btn text-lg"
              id="final-cta-btn"
            >
              Secure Lifetime Course Entry
            </button>
            <div className="text-[10px] text-cs-gray font-mono uppercase tracking-widest mt-2 flex items-center justify-center gap-4">
              <span>✓ Lifetime Access</span>
              <span>•</span>
              <span>✓ SECURE CHECKOUT PRESTIGE</span>
              <span>•</span>
              <span>✓ 30-DAY MONEY-BACK GUARANTEE</span>
            </div>
          </div>

        </div>
      </section>

    </div>
  );
}
