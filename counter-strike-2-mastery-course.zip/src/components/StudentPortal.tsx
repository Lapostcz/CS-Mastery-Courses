/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Play, CheckCircle, Circle, BookOpen, Award, Flame, 
  Map, MessageSquare, Send, UploadCloud, Lock, Check, 
  ExternalLink, FileText, Sliders, Target, Shield, Skull, Zap, Sparkles, Compass
} from 'lucide-react';
import { StudentEnrollment, Week, Lesson, UtilityLineup } from '../types';
import { weeksData, utilityDatabase } from '../data';

interface StudentPortalProps {
  enrollment: StudentEnrollment;
  onUpdateEnrollment: (updated: StudentEnrollment) => void;
  onUpgradeToPro: () => void;
}

export default function StudentPortal({
  enrollment,
  onUpdateEnrollment,
  onUpgradeToPro
}: StudentPortalProps) {
  // Navigation tabs inside portal
  const [activeTab, setActiveTab] = useState<'syllabus' | 'utility' | 'demo' | 'resources'>('syllabus');
  
  // Selected lesson state
  const [selectedLesson, setSelectedLesson] = useState<Lesson>(weeksData[0].lessons[0]);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  
  // Interactive utility filter configurations
  const [selectedMap, setSelectedMap] = useState<'All' | 'Mirage' | 'Inferno' | 'Dust II'>('All');
  const [selectedGrenadeType, setSelectedGrenadeType] = useState<'All' | 'Smoke' | 'Flash' | 'Molly'>('All');
  const [selectedSide, setSelectedSide] = useState<'All' | 'T' | 'CT'>('All');
  
  // Demo analysis simulation state
  const [demoCode, setDemoCode] = useState('');
  const [demoNotes, setDemoNotes] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisProgress, setAnalysisProgress] = useState('');

  // Auto-pause video if lesson changes
  useEffect(() => {
    setIsPlaying(false);
  }, [selectedLesson]);

  // Helper calculating overall percentage
  const totalLessonsCount = weeksData.reduce((acc, week) => acc + week.lessons.length, 0);
  const completedCount = enrollment.completedLessons.length;
  const progressPercent = Math.round((completedCount / totalLessonsCount) * 100);

  // Toggle lesson complete state
  const handleToggleLessonComplete = (lessonId: string) => {
    let updatedCompleted = [...enrollment.completedLessons];
    if (updatedCompleted.includes(lessonId)) {
      updatedCompleted = updatedCompleted.filter(id => id !== lessonId);
    } else {
      updatedCompleted.push(lessonId);
    }
    
    onUpdateEnrollment({
      ...enrollment,
      completedLessons: updatedCompleted
    });
  };

  // Run simulated coach review
  const handleDemoSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!demoCode.trim()) return;
    
    setIsAnalyzing(true);
    setAnalysisProgress("Uploading file chunk & mounting sandbox environment...");
    
    const steps = [
      "Decompressing CS2 128-tick spatial demo file...",
      "Analyzing player trajectory coordinates near choke points...",
      "Isolating head alignment parameters during pre-aim sequences...",
      "Cross-referencing utility bounce calculations with default models...",
      "Formulating diagnostic review sheets from Coach Vance..."
    ];

    let currentStep = 0;
    const interval = setInterval(() => {
      if (currentStep < steps.length) {
        setAnalysisProgress(steps[currentStep]);
        currentStep++;
      } else {
        clearInterval(interval);
        
        const feedbackTemplates = [
          `COACH DIAGNOSTIC ASSESSMENT — FOR STUDENT: ${enrollment.name}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Reviewer: Alex 'Karr' Vance
Map Inspected: Inferno (Demos Code Match: ${demoCode.substring(0, 10)})
Target Difficulty: Crouch Sprays & Retake Delay

CRITICAL WEAKNESSES IDENTIFIED:
1. Crouch-Spraying Trigger Fault: You are pressing the duck input ('CTRL') immediately on spotting targets at distances greater than 20 meters. This pins you to the spot and allows mid-tier opponents to tracking-lock your chest and secure standard bullet-rise headshots. 
REMEDY: Exercise the 'A-D' burst strafe. Do not crouch unless fire sequence exceeds 5 rounds.

2. Banana Defense Utility Spacing: Your deep banana Molotov timing was slow, consistently thrown at 1:42 which is 3 full seconds after competitive T-push pacing.
REMEDY: Practice the 'spawn-to-car' run throw line shown in Lesson 2.3.

STRENGTHS NOTED:
- Excellent crosshair height during site exit sweeps.
- Smart trade alignment with entry dueler. Keep that communication up!`,

          `COACH DIAGNOSTIC ASSESSMENT — FOR STUDENT: ${enrollment.name}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Reviewer: Dmitri 'Vortex' Rostov
Map Inspected: Mirage (Demos Code Match: ${demoCode.substring(0, 10)})
Target Difficulty: Mouse sensitivity and pathing

CRITICAL WEAKNESSES IDENTIFIED:
1. Micro-Adjustment Over-Flicking: In rounds 4, 7, and 12, your cursor overshot target movements in close quarters. This indicates your eDPI of ${1200} is generating rotational velocity beyond your muscle memory kinetic capture.
REMEDY: Remit sensitivity scale immediately by 15%. Target a uniform eDPI of 800 (e.g. 1.0 at 800 DPI). Spend 4 days on Recoil Master sheets.

2. Corner Slicing: You are hugging close-walls when circling connector corners, which reduces your reaction space relative to CT sniper angles.
REMEDY: Take wide, angled sweeps keeping maximum radius distance from the immediate wall.

STRENGTHS NOTED:
- Aggressive pop-flashing. Absolute perfect mechanical bounce indexes!`
        ];

        const randomReview = feedbackTemplates[Math.floor(Math.random() * feedbackTemplates.length)];

        onUpdateEnrollment({
          ...enrollment,
          submittedDemoUrl: demoCode,
          submittedDemoStatus: 'reviewed',
          demoReviewResult: randomReview
        });
        setIsAnalyzing(false);
        setDemoCode('');
        setDemoNotes('');
      }
    }, 1500);
  };

  // Filter utility database
  const filteredLineups = utilityDatabase.filter(item => {
    const mapMatch = selectedMap === 'All' || item.map === selectedMap;
    const typeMatch = selectedGrenadeType === 'All' || item.type === selectedGrenadeType;
    const sideMatch = selectedSide === 'All' || item.side === selectedSide;
    return mapMatch && typeMatch && sideMatch;
  });

  return (
    <div className="w-full max-w-7xl mx-auto px-4 md:px-6 py-8" id="student-portal-root">
      {/* Student Welcome bar with stats card */}
      <div className="bg-cs-surface border border-cs-border rounded-xl p-6 mb-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="space-y-1.5">
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono font-medium px-2 py-0.5 bg-cs-orange/10 border border-cs-orange/30 text-cs-orange rounded-full uppercase">
              {enrollment.tier === 'pro' ? '♛ PRO ENROLLED' : '✦ STANDARD'}
            </span>
            <span className="text-xs font-mono text-cs-gray">ID: {enrollment.id.substring(8, 15)}</span>
          </div>
          <h2 className="text-2xl md:text-3xl font-display font-bold text-white uppercase tracking-wide">
            Welcome Back, {enrollment.name}.
          </h2>
          <p className="text-sm text-cs-gray">
            Keep practicing daily mechanics to secure competitive gains. Today is a great day to drill aim routine.
          </p>
        </div>

        {/* Progress Display */}
        <div className="w-full md:w-80 bg-cs-dark border border-cs-border/60 p-4 rounded-lg space-y-3">
          <div className="flex justify-between items-center text-xs font-mono">
            <span className="text-cs-gray uppercase">Overall Module Progress</span>
            <span className="text-cs-yellow font-bold">{progressPercent}% ({completedCount}/{totalLessonsCount} Lessons)</span>
          </div>
          <div className="w-full h-2 bg-cs-surface border border-cs-border rounded-full overflow-hidden">
            <div 
              className="h-full bg-gradient-to-r from-cs-orange to-cs-yellow transition-all duration-500 rounded-full"
              style={{ width: `${progressPercent}%` }}
            ></div>
          </div>
          <div className="flex gap-4 text-[10px] font-mono justify-between text-cs-gray mt-1">
            <span className="flex items-center gap-1">
              <Flame size={12} className="text-cs-orange" /> Streak: 3 Days
            </span>
            <span className="flex items-center gap-1">
              <Award size={12} className="text-cs-yellow" /> Active Badge: recruit
            </span>
          </div>
        </div>
      </div>

      {/* Primary Dashboard Navigator */}
      <div className="flex border-b border-cs-border gap-2 mb-8 overflow-x-auto pb-px">
        <button
          onClick={() => setActiveTab('syllabus')}
          className={`px-5 py-3 font-display text-base uppercase tracking-widest font-bold border-b-2 transition-all duration-200 cursor-pointer whitespace-nowrap flex items-center gap-2 ${
            activeTab === 'syllabus' 
              ? 'border-cs-orange text-cs-orange bg-cs-orange/5' 
              : 'border-transparent text-cs-gray hover:text-white hover:bg-cs-surface/40'
          }`}
          id="tab-syllabus"
        >
          <BookOpen size={16} />
          Training Lectures ({completedCount}/{totalLessonsCount})
        </button>
        <button
          onClick={() => setActiveTab('utility')}
          className={`px-5 py-3 font-display text-base uppercase tracking-widest font-bold border-b-2 transition-all duration-200 cursor-pointer whitespace-nowrap flex items-center gap-2 ${
            activeTab === 'utility' 
              ? 'border-cs-orange text-cs-orange bg-cs-orange/5' 
              : 'border-transparent text-cs-gray hover:text-white hover:bg-cs-surface/40'
          }`}
          id="tab-utility"
        >
          <Map size={16} />
          Interactive Utility Room
        </button>
        <button
          onClick={() => setActiveTab('demo')}
          className={`px-5 py-3 font-display text-base uppercase tracking-widest font-bold border-b-2 transition-all duration-200 cursor-pointer whitespace-nowrap flex items-center gap-2 ${
            activeTab === 'demo' 
              ? 'border-cs-orange text-cs-orange bg-cs-orange/5' 
              : 'border-transparent text-cs-gray hover:text-white hover:bg-cs-surface/40'
          }`}
          id="tab-demo"
        >
          <Sliders size={16} />
          Demo Diagnostics & Review
        </button>
        <button
          onClick={() => setActiveTab('resources')}
          className={`px-5 py-3 font-display text-base uppercase tracking-widest font-bold border-b-2 transition-all duration-200 cursor-pointer whitespace-nowrap flex items-center gap-2 ${
            activeTab === 'resources' 
              ? 'border-cs-orange text-cs-orange bg-cs-orange/5' 
              : 'border-transparent text-cs-gray hover:text-white hover:bg-cs-surface/40'
          }`}
          id="tab-resources"
        >
          <Target size={16} />
          Config Download Hub
        </button>
      </div>

      {/* Content based on Active Tab */}
      
      {/* 1. SYLLABUS PANEL (LECTURES & VIDEO DRILLS) */}
      {activeTab === 'syllabus' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 animate-fade-in" id="syllabus-panel">
          
          {/* Left: Syllabus Tree Structure */}
          <div className="lg:col-span-4 space-y-4">
            <h3 className="font-display font-bold text-lg text-white uppercase tracking-wider mb-2 flex items-center gap-2">
              <FileText size={16} className="text-cs-orange" />
              Weekly Curriculum Outline
            </h3>
            
            <div className="space-y-5 max-h-[700px] overflow-y-auto pr-2">
              {weeksData.map((week) => (
                <div key={week.weekNumber} className="border border-cs-border/60 rounded-lg overflow-hidden bg-cs-surface/40">
                  <div className="bg-cs-surface border-b border-cs-border/60 px-4 py-3">
                    <div className="text-[10px] font-mono text-cs-yellow uppercase">Week {week.weekNumber} Training</div>
                    <h4 className="font-display font-extrabold text-sm uppercase text-white tracking-wide">{week.title}</h4>
                  </div>
                  
                  <div className="p-1 space-y-1">
                    {week.lessons.map((lesson) => {
                      const isSelected = selectedLesson.id === lesson.id;
                      const isDone = enrollment.completedLessons.includes(lesson.id);
                      return (
                        <button
                          key={lesson.id}
                          onClick={() => setSelectedLesson(lesson)}
                          className={`w-full text-left p-3 rounded-md flex items-start gap-3 transition-all duration-150 cursor-pointer ${
                            isSelected 
                              ? 'bg-cs-surface-light border-l-4 border-l-cs-orange pl-2 text-white' 
                              : 'text-cs-gray hover:text-white hover:bg-cs-surface/50'
                          }`}
                        >
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleToggleLessonComplete(lesson.id);
                            }}
                            className="text-cs-gray/80 hover:text-cs-orange transition-colors shrink-0 mt-0.5"
                          >
                            {isDone ? (
                              <CheckCircle size={16} className="text-cs-green" />
                            ) : (
                              <Circle size={16} className="text-cs-gray/50 hover:border-cs-orange" />
                            )}
                          </button>
                          
                          <div className="space-y-1 min-w-0">
                            <div className="text-[10px] uppercase font-mono tracking-wider flex items-center gap-1.5">
                              <span className="text-cs-gray">{lesson.duration}</span>
                              <span className="text-cs-border/80">•</span>
                              <span className={`px-1 rounded-[2px] font-bold text-[8px] ${
                                lesson.category === 'aim' ? 'text-[#FF3D00] bg-[#FF3D00]/10' :
                                lesson.category === 'utility' ? 'text-[#00B0FF] bg-[#00B0FF]/10' :
                                lesson.category === 'movement' ? 'text-[#00E676] bg-[#00E676]/10' :
                                lesson.category === 'economy' ? 'text-[#FFD600] bg-[#FFD600]/10' : 'text-[#AA00FF] bg-[#AA00FF]/10'
                              }`}>{lesson.category}</span>
                            </div>
                            <h5 className="font-medium text-xs truncate leading-tight">{lesson.title}</h5>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Right: Active Course Player */}
          <div className="lg:col-span-8 space-y-6">
            <div className="bg-cs-surface border border-cs-border rounded-xl spill-hidden overflow-hidden shadow-lg">
              
              {/* Fake Interactive Video Screen */}
              <div className="relative aspect-video bg-black flex items-center justify-center overflow-hidden group">
                {isPlaying ? (
                  <iframe 
                    className="w-full h-full text-white"
                    src={`${selectedLesson.videoUrl}?autoplay=1&mute=1&controls=1&modestbranding=1&rel=0`}
                    title={selectedLesson.title}
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                  ></iframe>
                ) : (
                  <>
                    <img 
                      src="https://images.unsplash.com/photo-1542751371-adc38448a05e?q=80&w=1200&h=675&fit=crop" 
                      alt="CS2 Course Video Cover" 
                      className="absolute inset-0 w-full h-full object-cover filter brightness-40 blur-[2px] opacity-75 group-hover:scale-105 transition-transform duration-700 pointer-events-none"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-black/10"></div>
                    
                    {/* Retro coordinate layout decor */}
                    <div className="absolute top-4 left-4 font-mono text-[9px] text-cs-yellow/60 select-none">
                      SECURE_FEED: CS2_HUD_V2 // T_SPAWN_MARKERS_ACTIVE
                    </div>
                    <div className="absolute top-4 right-4 font-mono text-[9px] text-cs-gray select-none">
                      STREAM RATE: 10.4 MB/S // QUALITY: 1080P
                    </div>

                    <div className="relative z-10 text-center px-4 max-w-lg space-y-4">
                      <button 
                        onClick={() => setIsPlaying(true)}
                        className="mx-auto w-20 h-20 rounded-full bg-cs-orange hover:bg-cs-orange/90 text-white flex items-center justify-center shadow-xl transition-all duration-300 hover:scale-110 active:scale-95 glow-btn cursor-pointer"
                        id="play-video-btn"
                      >
                        <Play size={32} className="ml-2 fill-white" />
                      </button>
                      
                      <div className="space-y-1">
                        <span className="text-[10px] font-mono uppercase tracking-widest text-cs-yellow">ACTIVE LESSON FEED</span>
                        <h4 className="text-xl md:text-2xl font-display font-black text-white uppercase tracking-wide">
                          {selectedLesson.title}
                        </h4>
                        <p className="text-xs text-cs-gray leading-relaxed max-w-sm mx-auto">
                          Click to play the interactive training lecture. Focus on physical adjustments highlighted in notes.
                        </p>
                      </div>
                    </div>
                  </>
                )}
              </div>

              {/* Information / Action footer */}
              <div className="p-6 md:p-8 space-y-6 bg-cs-surface-light border-t border-cs-border">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-cs-border pb-6">
                  <div>
                    <span className="text-xs font-mono uppercase text-cs-orange font-bold">LECTURE SYLLABUS</span>
                    <h4 className="text-xl font-display font-extrabold text-white uppercase tracking-wide mt-0.5">
                      {selectedLesson.title}
                    </h4>
                    <p className="text-sm text-cs-gray mt-1 leading-relaxed">
                      {selectedLesson.description}
                    </p>
                  </div>
                  
                  <button
                    onClick={() => handleToggleLessonComplete(selectedLesson.id)}
                    className={`w-full sm:w-auto px-5 py-2.5 rounded-lg font-mono text-xs uppercase font-bold tracking-wider cursor-pointer flex items-center justify-center gap-2 transition-all duration-200 ${
                      enrollment.completedLessons.includes(selectedLesson.id)
                        ? 'bg-cs-green/10 border border-cs-green/30 text-cs-green'
                        : 'bg-cs-orange hover:bg-cs-orange hover:text-white text-white border border-transparent'
                    }`}
                    id="lesson-status-toggle"
                  >
                    {enrollment.completedLessons.includes(selectedLesson.id) ? (
                      <>
                        <Check size={14} /> Completed Draft
                      </>
                    ) : (
                      'Mark Lesson as Finished'
                    )}
                  </button>
                </div>

                {/* Subsections */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
                  <div className="space-y-2.5 bg-cs-dark border border-cs-border/80 rounded-lg p-5">
                    <h5 className="font-display font-black text-xs uppercase text-white tracking-widest flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 bg-cs-orange rounded-full"></span>
                      1. Homework Task Checklist
                    </h5>
                    <p className="text-xs text-cs-gray leading-relaxed">
                      {selectedLesson.assignment}
                    </p>
                  </div>

                  <div className="space-y-2.5 bg-cs-dark border border-cs-border/80  rounded-lg p-5">
                    <h5 className="font-display font-black text-xs uppercase text-white tracking-widest flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 bg-cs-yellow rounded-full"></span>
                      2. Practical Exercise (Local Practice Server)
                    </h5>
                    <p className="text-xs text-cs-gray leading-relaxed font-mono">
                      {selectedLesson.practicalActivity}
                    </p>
                  </div>
                </div>

              </div>
            </div>
          </div>
        </div>
      )}

      {/* 2. INTERACTIVE UTILITY DATABASE STUDY ROOM */}
      {activeTab === 'utility' && (
        <div className="space-y-6 animate-fade-in" id="utility-panel">
          <div className="bg-cs-surface border border-cs-border rounded-xl p-6 space-y-4">
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
              <div>
                <span className="text-xs font-mono uppercase text-cs-orange font-bold">TACTICAL DATABASE</span>
                <h3 className="text-2xl font-display font-black text-white uppercase tracking-wider">
                  Interactive CS2 Utility Lineups
                </h3>
                <p className="text-xs text-cs-gray">
                  Never throw blind utility. Filter and study lineups with zero margin of error. Setup local lobby with cheat flags to align.
                </p>
              </div>
              <div className="text-xs font-mono text-cs-yellow bg-cs-yellow/5 border border-cs-yellow/10 px-3 py-1.5 rounded-lg flex items-center gap-2">
                <Sliders size={12} /> Live Utility Bank: {filteredLineups.length} Guides Available
              </div>
            </div>

            {/* Filters panel */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4 border-t border-cs-border/50">
              
              {/* Map selection */}
              <div>
                <label className="block text-[10px] font-mono uppercase text-cs-gray mb-1.5">Map Environment</label>
                <div className="flex gap-1.5 flex-wrap">
                  {['All', 'Mirage', 'Inferno', 'Dust II'].map(map => (
                    <button
                      key={map}
                      onClick={() => setSelectedMap(map as any)}
                      className={`px-3 py-1.5 rounded text-xs font-mono transition-colors uppercase cursor-pointer ${
                        selectedMap === map 
                          ? 'bg-cs-orange text-white' 
                          : 'bg-cs-dark text-cs-gray hover:text-white hover:bg-cs-dark/80 border border-cs-border/60'
                      }`}
                    >
                      {map}
                    </button>
                  ))}
                </div>
              </div>

              {/* Utility Type */}
              <div>
                <label className="block text-[10px] font-mono uppercase text-cs-gray mb-1.5">Grenade Category</label>
                <div className="flex gap-1.5 flex-wrap">
                  {['All', 'Smoke', 'Flash', 'Molly'].map(g => (
                    <button
                      key={g}
                      onClick={() => setSelectedGrenadeType(g as any)}
                      className={`px-3 py-1.5 rounded text-xs font-mono transition-colors uppercase cursor-pointer ${
                        selectedGrenadeType === g 
                          ? 'bg-cs-orange text-white' 
                          : 'bg-cs-dark text-cs-gray hover:text-white hover:bg-cs-dark/80 border border-cs-border/60'
                      }`}
                    >
                      {g}
                    </button>
                  ))}
                </div>
              </div>

              {/* Side */}
              <div>
                <label className="block text-[10px] font-mono uppercase text-cs-gray mb-1.5">Strategic Alignment</label>
                <div className="flex gap-1.5 flex-wrap">
                  {['All', 'T', 'CT'].map(side => (
                    <button
                      key={side}
                      onClick={() => setSelectedSide(side as any)}
                      className={`px-3 py-1.5 rounded text-xs font-mono transition-colors uppercase cursor-pointer ${
                        selectedSide === side 
                          ? 'bg-cs-orange text-white' 
                          : 'bg-cs-dark text-cs-gray hover:text-white hover:bg-cs-dark/80 border border-cs-border/60'
                      }`}
                    >
                      {side === 'All' ? 'ALL SIDES' : side === 'T' ? 'T ATTACK' : 'CT DEFENSE'}
                    </button>
                  ))}
                </div>
              </div>

            </div>
          </div>

          {/* Database Results grid */}
          {filteredLineups.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {filteredLineups.map((item) => (
                <div 
                  key={item.id} 
                  className="bg-cs-surface border border-cs-border/80 rounded-xl overflow-hidden hover:border-cs-orange/50 transition-all duration-300 shadow-md group"
                >
                  <div className="bg-cs-surface-light border-b border-cs-border p-4 flex justify-between items-center">
                    <div className="space-y-0.5">
                      <span className="text-[10px] font-mono text-cs-yellow uppercase tracking-wider">{item.map} // {item.side === 'T' ? 'Terrorist' : 'Counter-Terrorist'}</span>
                      <h4 className="font-display font-black text-sm uppercase text-white tracking-widest">{item.name}</h4>
                    </div>
                    <span className={`px-2 py-0.5 text-[9px] font-mono rounded font-bold uppercase tracking-widest ${
                      item.type === 'Smoke' ? 'text-blue-400 bg-blue-500/10' :
                      item.type === 'Flash' ? 'text-yellow-400 bg-yellow-500/10' : 'text-red-400 bg-red-500/10'
                    }`}>{item.type}</span>
                  </div>

                  <div className="p-5 space-y-4">
                    <p className="text-xs text-cs-gray leading-relaxed text-slate-300">
                      {item.description}
                    </p>

                    <div className="bg-cs-dark border border-cs-border/50 rounded-lg p-4 space-y-3 font-mono text-[11px]">
                      <div className="flex items-start gap-2 border-b border-cs-border/30 pb-2">
                        <span className="text-cs-orange font-bold select-none shrink-0">[STAND SPOT]</span>
                        <span className="text-white leading-normal">{item.standSpot}</span>
                      </div>
                      <div className="flex items-start gap-2 border-b border-cs-border/30 pb-2">
                        <span className="text-cs-yellow font-bold select-none shrink-0">[CROSSHAIR]</span>
                        <span className="text-white leading-normal">{item.crosshairPlace}</span>
                      </div>
                      <div className="flex justify-between items-center text-[10px] pt-1">
                        <span className="text-cs-gray uppercase font-semibold">Throw Technique:</span>
                        <span className="px-2 py-0.5 bg-cs-surface border border-cs-border text-white rounded font-bold text-[9px] uppercase tracking-wider text-cs-orange/95">
                          {item.throwType}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-20 bg-cs-surface border border-cs-border/60 rounded-xl space-y-3">
              <Compass className="mx-auto text-cs-gray/40 animate-pulse" size={48} />
              <h4 className="font-display font-bold text-lg text-white uppercase tracking-wider">No Lineups Match Filter Range</h4>
              <p className="text-xs text-cs-gray max-w-sm mx-auto">
                Reset your map or grenade category configurations to view standard strategic alignment templates.
              </p>
              <button
                onClick={() => {
                  setSelectedMap('All');
                  setSelectedGrenadeType('All');
                  setSelectedSide('All');
                }}
                className="px-4 py-2 bg-cs-border hover:bg-cs-orange text-white transition-colors rounded text-xs font-mono uppercase tracking-wider cursor-pointer"
              >
                Restore Standard View
              </button>
            </div>
          )}
        </div>
      )}

      {/* 3. DEMO DIAGNOSTICS & AI COACH REVIEW HUB */}
      {activeTab === 'demo' && (
        <div className="space-y-6 animate-fade-in" id="demo-panel">
          
          {/* Locked Overlay if user is in Standard Tier */}
          {enrollment.tier !== 'pro' ? (
            <div className="bg-cs-surface border border-cs-border rounded-xl p-8 relative overflow-hidden">
              {/* Decorative backlines */}
              <div className="absolute inset-0 scanline-overlay opacity-5 pointer-events-none"></div>
              
              <div className="max-w-xl mx-auto text-center space-y-6 py-12 relative z-10">
                <div className="w-20 h-20 rounded-full bg-cs-orange/10 border-2 border-cs-border flex items-center justify-center mx-auto text-cs-orange">
                  <Lock size={36} />
                </div>
                
                <div className="space-y-2">
                  <span className="text-xs font-mono tracking-widest text-cs-yellow uppercase block font-bold">PRO BUNDLE GATEWAY</span>
                  <h3 className="text-3xl font-display font-black text-white uppercase tracking-wider">
                    PERSONAL COACH DEMO DIAGNOSTICS
                  </h3>
                  <p className="text-sm text-cs-gray leading-relaxed">
                    Analyzing standard match demos from premium queues (Faceit/Matchmaking) requires manual coach inspection. Our instructors isolate your crosshair flaws, physical movement lag, and send custom remedy worksheets.
                  </p>
                </div>

                <div className="bg-cs-dark border border-cs-border/60 rounded-lg p-5 text-left text-xs space-y-3 max-w-sm mx-auto">
                  <div className="flex items-center gap-2 text-white">
                    <Check size={14} className="text-cs-green" /> Verbatim spatial path reviews
                  </div>
                  <div className="flex items-center gap-2 text-white">
                    <Check size={14} className="text-cs-green" /> Sensitivity matching and audit logs
                  </div>
                  <div className="flex items-center gap-2 text-white">
                    <Check size={14} className="text-cs-green" /> Personal utility delay analytics
                  </div>
                </div>

                <div className="pt-2">
                  <button
                    onClick={onUpgradeToPro}
                    className="px-8 py-3.5 bg-gradient-to-r from-cs-orange to-cs-yellow text-white font-display font-extrabold uppercase text-lg tracking-wider rounded-lg shadow-lg hover:brightness-105 active:scale-95 transition-all cursor-pointer glow-btn flex items-center justify-center gap-2 mx-auto"
                    id="upgrade-pro-btn"
                  >
                    <Sparkles size={18} />
                    Upgrade to Pro Bundle — Only +$30.00
                  </button>
                  <p className="text-[10px] text-cs-gray mt-2 font-mono">
                    Instant upgrade. Secures 1-hour private demo coach review.
                  </p>
                </div>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              
              {/* Left Form: Submit Match demo */}
              <div className="lg:col-span-5 bg-cs-surface border border-cs-border rounded-xl p-6 md:p-8 space-y-6">
                <div>
                  <span className="text-xs font-mono text-cs-orange font-bold block uppercase mb-1">PRO STUDIO CONTROLS</span>
                  <h4 className="text-xl font-display font-bold text-white uppercase tracking-wide">Submit Match Demo</h4>
                  <p className="text-xs text-cs-gray mt-1">
                    Upload your match credentials. Match files will be parsed by mechanical sensors, cross-referenced with Faceit Level 10 baselines, and reported directly.
                  </p>
                </div>

                <form onSubmit={handleDemoSubmit} className="space-y-4">
                  <div>
                    <label className="block text-[10px] font-mono uppercase text-cs-gray mb-1.5 font-medium">CS2 Match Steam Code or Demo Code</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. CSGO-abCdE-fGhIj-12345-KLMNo-PQRSt"
                      value={demoCode}
                      onChange={(e) => setDemoCode(e.target.value)}
                      className="w-full px-4 py-2 bg-cs-dark border border-cs-border rounded-lg text-white font-mono placeholder-cs-gray/30 focus:outline-none focus:border-cs-orange text-xs transition-colors"
                    />
                    <span className="text-[9px] text-cs-gray block mt-1.5 leading-normal">
                      Can be copied inside your personal CS2 client watch history ('Share Match Link').
                    </span>
                  </div>

                  <div>
                    <label className="block text-[10px] font-mono uppercase text-cs-gray mb-1.5 font-medium">Diagnostic Target / Frustrations (Optional)</label>
                    <textarea
                      rows={3}
                      placeholder="e.g. My aim feels inconsistent on CT side. Kept losing entry fights on Long A dust2..."
                      value={demoNotes}
                      onChange={(e) => setDemoNotes(e.target.value)}
                      className="w-full px-4 py-2 bg-cs-dark border border-cs-border rounded-lg text-white font-sans placeholder-cs-gray/30 focus:outline-none focus:border-cs-orange text-xs transition-colors resize-none"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={isAnalyzing || !demoCode.trim()}
                    className="w-full py-2.5 bg-cs-orange disabled:bg-cs-border hover:bg-cs-orange/95 text-white font-display font-bold uppercase tracking-wider rounded-lg transition-all text-sm cursor-pointer flex items-center justify-center gap-2"
                    id="submit-demo-analysis"
                  >
                    <UploadCloud size={16} />
                    {isAnalyzing ? "Processing Analytics..." : "Launch Kinetic Review"}
                  </button>
                </form>

                {isAnalyzing && (
                  <div className="p-4 bg-cs-dark border border-cs-border rounded-lg text-center space-y-3 font-mono text-xs">
                    <div className="w-6 h-6 rounded-full border-2 border-cs-orange border-t-transparent animate-spin mx-auto"></div>
                    <div className="text-cs-yellow font-bold uppercase animate-pulse">{analysisProgress}</div>
                    <p className="text-[10px] text-cs-gray">
                      Compiling positional data packets. Estimated time remaining: ~5 seconds.
                    </p>
                  </div>
                )}
              </div>

              {/* Right panel: Active Diagnostic Feedback */}
              <div className="lg:col-span-7 bg-cs-surface border border-cs-border rounded-xl p-6 md:p-8 space-y-6 flex flex-col justify-between">
                <div>
                  <h4 className="font-display font-bold text-lg text-white uppercase tracking-wider border-b border-cs-border pb-4 flex items-center justify-between">
                    <span>REPORT HISTORIES</span>
                    <span className="text-xs font-mono font-normal text-cs-green flex items-center gap-1">
                      <span className="w-2 h-2 rounded-full bg-cs-green animate-pulse"></span>
                      COACH ACTIVE
                    </span>
                  </h4>
                  
                  {enrollment.submittedDemoStatus === 'reviewed' && enrollment.demoReviewResult ? (
                    <div className="mt-4 bg-cs-dark border border-cs-border rounded-lg p-5 font-mono text-xs text-cs-light leading-relaxed whitespace-pre-line select-text max-h-[480px] overflow-y-auto border-l-4 border-l-cs-orange bg-opacity-40">
                      {enrollment.demoReviewResult}
                    </div>
                  ) : (
                    <div className="mt-8 text-center py-16 space-y-3">
                      <Sliders size={36} className="text-cs-gray/30 mx-auto" />
                      <h5 className="font-display font-bold text-sm text-white uppercase tracking-wider">No Reviews Outstanding</h5>
                      <p className="text-xs text-cs-gray max-w-xs mx-auto">
                        Your coaching portfolio is empty. Submit a steam matchmaking code on the left to trigger the mechanical coach review.
                      </p>
                    </div>
                  )}
                </div>

                <div className="text-[10px] font-mono text-cs-gray border-t border-cs-border/40 pt-4 mt-6 leading-relaxed">
                  SYSTEM REMARK: Pro coaching services allow 1 analysis ticket per week. For custom premium team diagnostics, please contact Karr on Discord.
                </div>
              </div>

            </div>
          )}

        </div>
      )}

      {/* 4. PRIVATE DISCORD AND CONFIG RESOURCE HUB */}
      {activeTab === 'resources' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 animate-fade-in" id="resources-panel">
          
          {/* Discord Space */}
          <div className="bg-cs-surface border border-cs-border rounded-xl p-6 md:p-8 space-y-6">
            <div className="space-y-1">
              <span className="text-xs font-mono text-[#5865F2] font-bold block uppercase">VERIFIED GUILD</span>
              <h4 className="text-xl font-display font-bold text-white uppercase tracking-wide flex items-center gap-2">
                <MessageSquare size={18} /> Private Discord Access
              </h4>
              <p className="text-xs text-cs-gray">
                Gain entry to our competitive gamers hub. Chat with players, exchange customized workshop links, find non-toxic queues, and coordinate daily 5-man lobbies.
              </p>
            </div>

            <div className="bg-cs-dark border border-cs-border/60 rounded-lg p-5 space-y-4">
              <div className="flex justify-between items-center border-b border-cs-border/30 pb-3">
                <span className="text-xs text-cs-gray font-mono uppercase">GUILD STATUS</span>
                <span className="text-xs text-cs-green font-mono font-bold flex items-center gap-1">
                  <span className="w-1.5 h-1.5 bg-cs-green rounded-full"></span> 248 ONLINE NOW
                </span>
              </div>

              <div className="space-y-2.5 text-xs text-slate-300">
                <div className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 bg-cs-orange rounded-full"></span> Aim calibrations channels
                </div>
                <div className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 bg-cs-orange rounded-full"></span> Matchmaking looking-for-group (LFG) channels
                </div>
                <div className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 bg-cs-orange rounded-full"></span> Pro-match commentary channels
                </div>
              </div>
            </div>

            <a 
              href="https://discord.gg"
              target="_blank"
              rel="noreferrer"
              className="w-full py-3 bg-[#5865F2] hover:bg-[#4752C4] text-white font-display font-extrabold text-sm uppercase text-center tracking-wider rounded-lg shadow-lg flex items-center justify-center gap-2"
              id="join-discord-link"
            >
              Secure Discord Invite Code
              <ExternalLink size={16} />
            </a>
          </div>

          {/* Config Hub */}
          <div className="bg-cs-surface border border-cs-border rounded-xl p-6 md:p-8 space-y-6">
            <div className="space-y-1">
              <span className="text-xs font-mono text-cs-orange font-bold block uppercase">CONFIG COMPILATIONS</span>
              <h4 className="text-xl font-display font-bold text-white uppercase tracking-wide flex items-center gap-2">
                <Sliders size={18} /> Pro Calibration Presets
              </h4>
              <p className="text-xs text-cs-gray">
                Download copyable configuration presets and console command configurations to instantly standardize your game environment constraints.
              </p>
            </div>

            <div className="space-y-3">
              {/* Box 1 */}
              <div className="bg-cs-dark border border-cs-border/60 p-4 rounded-lg flex items-center justify-between">
                <div>
                  <div className="text-xs font-mono text-white font-bold">Standard Jump-Throw & Bind config.cfg</div>
                  <div className="text-[10px] text-cs-gray font-mono mt-0.5">Updated for latest CS2 engine variables.</div>
                </div>
                <button
                  onClick={() => alert("Copied console setup: bind 'j' '+jump'; bind 'k' '-attack';")}
                  className="px-3 py-1.5 bg-cs-border hover:bg-cs-orange text-white text-[10px] font-mono rounded transition-colors uppercase cursor-pointer shrink-0"
                >
                  Copy Binds
                </button>
              </div>

              {/* Box 2 */}
              <div className="bg-cs-dark border border-cs-border/60 p-4 rounded-lg flex items-center justify-between">
                <div>
                  <div className="text-xs font-mono text-white font-bold">Coach Karr's Personal Crosshair Profile</div>
                  <div className="text-[10px] text-cs-gray font-mono mt-0.5">CS2-378mJ-vR6zO-hS7N9-o3XU8</div>
                </div>
                <button
                  onClick={() => alert("Copied Crosshair Code: CS2-378mJ-vR6zO-hS7N9-o3XU8")}
                  className="px-3 py-1.5 bg-cs-border hover:bg-cs-orange text-white text-[10px] font-mono rounded transition-colors uppercase cursor-pointer shrink-0"
                >
                  Copy Code
                </button>
              </div>

              {/* Box 3 */}
              <div className="bg-cs-dark border border-cs-border/60 p-4 rounded-lg flex items-center justify-between">
                <div>
                  <div className="text-xs font-mono text-white font-bold">High FPS Video settings Optimization Sheet</div>
                  <div className="text-[10px] text-cs-gray font-mono mt-0.5">Step-by-step PDF manual of driver calibrations.</div>
                </div>
                <button
                  onClick={() => alert("Calibration Manual downloaded! Target: Reflex Low Latency: ON, Shadows: MEDIUM.")}
                  className="px-3 py-1.5 bg-cs-border hover:bg-cs-orange text-white text-[10px] font-mono rounded transition-colors uppercase cursor-pointer shrink-0"
                >
                  Download Info
                </button>
              </div>
            </div>

            <div className="text-[10px] font-mono text-cs-gray leading-relaxed italic">
              *Paste configuration strings directly into your CS2 developer console to update variables instantly. Enable Developer Console in game settings first.
            </div>
          </div>

        </div>
      )}

    </div>
  );
}
