/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { HelpCircle, ChevronDown, ChevronRight, MessageSquare, Compass } from 'lucide-react';
import { faqData } from '../data';

export default function FAQPage() {
  const [openId, setOpenId] = useState<string | null>("faq-1");
  const [activeCategory, setActiveCategory] = useState<'All' | 'payment' | 'course' | 'schedule' | 'coaching'>('All');

  const toggleFAQ = (id: string) => {
    setOpenId(openId === id ? null : id);
  };

  const categories = {
    All: "All Inquiries",
    course: "Course & Rig",
    schedule: "Timelines & Access",
    payment: "Payments & Guarantee",
    coaching: "Coaching Tickets"
  };

  const filteredFAQs = faqData.filter(item => {
    return activeCategory === 'All' || item.category === activeCategory;
  });

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-12 animate-fade-in" id="faq-root">
      
      {/* FAQ Header */}
      <div className="text-center space-y-3 max-w-xl mx-auto">
        <span className="text-xs font-mono text-cs-orange font-bold uppercase tracking-widest">[QUERY TERMINAL]</span>
        <h1 className="text-4xl font-display font-black text-white uppercase tracking-wide">
          COMMON CONCERNS
        </h1>
        <p className="text-xs text-cs-gray leading-relaxed font-sans text-slate-300">
          Have questions before you register? Review answers below. If your inquiry is regarding custom team analytics, please draft a support ticket inside the contact workspace.
        </p>
      </div>

      {/* Category Pills */}
      <div className="flex flex-wrap gap-2 justify-center border-b border-cs-border/40 pb-6">
        {Object.entries(categories).map(([key, name]) => (
          <button
            key={key}
            onClick={() => setActiveCategory(key as any)}
            className={`px-3.5 py-1.5 font-mono text-xs uppercase font-semibold rounded cursor-pointer transition-colors ${
              activeCategory === key 
                ? 'bg-cs-orange text-white' 
                : 'bg-cs-surface text-cs-gray hover:text-white border border-cs-border/50'
            }`}
          >
            {name}
          </button>
        ))}
      </div>

      {/* Accordion Layout */}
      <div className="space-y-4">
        {filteredFAQs.map((faq) => {
          const isOpen = openId === faq.id;
          return (
            <div 
              key={faq.id} 
              className="bg-cs-surface border border-cs-border rounded-xl overflow-hidden transition-all duration-200"
            >
              <button
                onClick={() => toggleFAQ(faq.id)}
                className="w-full text-left p-5 md:p-6 flex justify-between items-center gap-4 hover:bg-cs-surface-light/40 transition-colors cursor-pointer"
                id={`faq-btn-${faq.id}`}
              >
                <span className="font-display font-extrabold text-sm md:text-base text-white uppercase tracking-wider leading-snug">
                  {faq.question}
                </span>
                <span className="text-cs-orange shrink-0">
                  {isOpen ? <ChevronDown size={18} /> : <ChevronRight size={18} />}
                </span>
              </button>

              {isOpen && (
                <div 
                  className="p-5 md:p-6 bg-cs-dark/20 text-xs md:text-sm text-cs-gray leading-relaxed border-t border-cs-border/40 font-sans text-slate-300 animate-slide-down"
                  id={`faq-answer-${faq.id}`}
                >
                  {faq.answer}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Box fallback */}
      <div className="bg-cs-surface border border-cs-border rounded-2xl p-6 md:p-8 text-center space-y-4 max-w-2xl mx-auto">
        <MessageSquare className="mx-auto text-cs-orange" size={24} />
        <h4 className="font-display font-black text-sm text-white uppercase tracking-wider">Still Have Questions?</h4>
        <p className="text-xs text-cs-gray max-w-sm mx-auto">
          Our esports coaches are active inside our support workspace. Draft a detailed ticket, and Karr will examine it.
        </p>
      </div>

    </div>
  );
}
