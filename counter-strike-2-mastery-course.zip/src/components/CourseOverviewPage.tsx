/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { BookOpen, Clock, Target, CheckSquare, ListFilter, HelpCircle, Award } from 'lucide-react';
import { weeksData } from '../data';
import { Lesson } from '../types';

interface CourseOverviewPageProps {
  onOpenCheckout: (tier: 'standard' | 'pro') => void;
}

export default function CourseOverviewPage({ onOpenCheckout }: CourseOverviewPageProps) {
  const [activeCategory, setActiveCategory] = useState<'All' | 'aim' | 'utility' | 'movement' | 'teamplay' | 'mindset'>('All');

  // Filter lessons from all weeks
  const allLessons = weeksData.reduce((acc: Lesson[], week) => {
    return [...acc, ...week.lessons];
  }, []);

  const filteredLessons = allLessons.filter(lesson => {
    return activeCategory === 'All' || lesson.category === activeCategory;
  });

  const categoryLabels = {
    All: "All Classes",
    aim: "Aim Mechanics",
    utility: "Utility Executes",
    movement: "Kinetic Movement",
    teamplay: "Team Dynamics",
    mindset: "Psychology & Stats"
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-16 animate-fade-in" id="curriculum-root">
      
      {/* Page Header */}
      <div className="text-center space-y-3 max-w-2xl mx-auto">
        <span className="text-xs font-mono text-cs-orange font-bold uppercase tracking-widest">[SYLLABUS REPORT]</span>
        <h1 className="text-4xl md:text-5xl font-display font-black text-white uppercase tracking-wide">
          COURSE CURRICULUM CATALOG
        </h1>
        <p className="text-sm text-cs-gray leading-relaxed">
          Explore our professional-grade Counter-Strike 2 competitive curriculum. A week-by-week sequence engineered to replace sub-conscious errors with high-Elo formulas.
        </p>
      </div>

      {/* category Filtration Pills */}
      <div className="bg-cs-surface border border-cs-border rounded-xl p-4 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-2 text-xs font-mono text-cs-gray">
          <ListFilter size={16} className="text-cs-orange" />
          <span>Filter Course Modules:</span>
        </div>
        <div className="flex flex-wrap gap-1.5 justify-center">
          {Object.entries(categoryLabels).map(([key, value]) => (
            <button
              key={key}
              onClick={() => setActiveCategory(key as any)}
              className={`px-3 py-1.5 font-mono text-xs uppercase font-semibold rounded cursor-pointer transition-colors ${
                activeCategory === key 
                  ? 'bg-cs-orange text-white' 
                  : 'bg-cs-dark text-cs-gray hover:text-white border border-cs-border/60'
              }`}
            >
              {value}
            </button>
          ))}
        </div>
      </div>

      {/* Main Syllabus Layout */}
      {activeCategory === 'All' ? (
        <div className="space-y-12">
          {weeksData.map((week) => (
            <div key={week.weekNumber} className="bg-cs-surface border border-cs-border rounded-2xl overflow-hidden shadow-xl" id={`week-block-${week.weekNumber}`}>
              
              {/* Week Title Header Banner */}
              <div className="p-6 md:p-8 bg-cs-surface-light border-b border-cs-border flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
                <div className="space-y-1.5">
                  <span className="text-xs font-mono text-cs-orange font-bold uppercase tracking-wider">MODULE STAGE 0{week.weekNumber}</span>
                  <h3 className="text-2xl md:text-3xl font-display font-black text-white uppercase tracking-wider">{week.title}</h3>
                  <p className="text-xs text-cs-gray font-mono italic">{week.subtitle}</p>
                </div>
                
                {/* Stats Summary Badge */}
                <div className="flex gap-4 font-mono text-[10px] text-cs-gray">
                  <span className="bg-cs-dark border border-cs-border/50 px-3 py-1.5 rounded flex items-center gap-1">
                    <Clock size={12} className="text-cs-orange" /> {week.lessons.length * 20} Min Course Load
                  </span>
                  <span className="bg-cs-dark border border-cs-border/50 px-3 py-1.5 rounded flex items-center gap-1">
                    <BookOpen size={12} className="text-cs-yellow" /> {week.lessons.length} Detailed Lectures
                  </span>
                </div>
              </div>

              {/* Week Description Statement */}
              <div className="px-6 md:px-8 py-5 bg-cs-dark/20 text-xs text-slate-300 border-b border-cs-border/40 leading-relaxed font-sans">
                {week.description}
              </div>

              {/* Lessons Stack list */}
              <div className="divide-y divide-cs-border/40">
                {week.lessons.map((lesson, idx) => (
                  <div key={lesson.id} className="p-6 md:p-8 flex flex-col lg:flex-row gap-6 hover:bg-cs-surface-light/40 transition-colors">
                    
                    {/* Index count & specs */}
                    <div className="lg:w-48 shrink-0 space-y-1">
                      <span className="text-[10px] font-mono text-cs-gray uppercase">Lesson 0{idx + 1}</span>
                      <div className="flex items-center gap-2">
                        <span className="text-white font-mono text-xs font-bold bg-cs-dark px-2 py-0.5 rounded border border-cs-border">{lesson.duration}</span>
                        <span className={`px-2 py-0.5 text-[8px] font-mono rounded font-bold uppercase ${
                          lesson.category === 'aim' ? 'text-red-400 bg-red-500/10' :
                          lesson.category === 'utility' ? 'text-blue-400 bg-blue-500/10' :
                          lesson.category === 'movement' ? 'text-cs-green bg-cs-green/10' :
                          lesson.category === 'economy' ? 'text-cs-yellow bg-cs-yellow/10' : 'text-purple-400 bg-purple-500/10'
                        }`}>{lesson.category}</span>
                      </div>
                    </div>

                    {/* Lesson Core description */}
                    <div className="flex-1 space-y-2">
                      <h4 className="font-display font-extrabold text-white text-base uppercase tracking-wider">{lesson.title}</h4>
                      <p className="text-xs text-cs-gray leading-relaxed text-slate-300 font-sans">{lesson.description}</p>
                    </div>

                    {/* homework assignment review */}
                    <div className="lg:w-80 shrink-0 bg-cs-dark border border-cs-border/60 p-4 rounded-lg space-y-2 font-mono text-[10px] text-slate-300">
                      <div className="flex items-center gap-1.5 text-white font-bold border-b border-cs-border/40 pb-1 text-xs">
                        <CheckSquare size={12} className="text-cs-orange" />
                        <span>Actionable Homework Task</span>
                      </div>
                      <p className="leading-relaxed">
                        {lesson.assignment}
                      </p>
                    </div>

                  </div>
                ))}
              </div>

            </div>
          ))}
        </div>
      ) : (
        /* Category-filtered flat View list */
        <div className="bg-cs-surface border border-cs-border rounded-xl spill-hidden overflow-hidden shadow-xl division-y division-cs-border/60">
          <div className="p-4 bg-cs-surface-light border-b border-cs-border font-mono text-xs text-cs-yellow uppercase tracking-wider font-semibold">
            Filtered Lectures Match Category: {activeCategory.toUpperCase()} ({filteredLessons.length} Lectures)
          </div>
          
          <div className="divide-y divide-cs-border/60">
            {filteredLessons.map((lesson) => (
              <div key={lesson.id} className="p-6 flex flex-col md:flex-row gap-6 hover:bg-cs-surface-light/20 transition-colors">
                <div className="md:w-32 shrink-0 space-y-1 font-mono text-xs">
                  <div className="text-white font-bold">{lesson.duration}</div>
                  <span className="px-2 py-0.5 text-[8px] bg-cs-orange/10 text-cs-orange font-bold uppercase tracking-widest rounded">{lesson.category}</span>
                </div>
                
                <div className="flex-1 space-y-2">
                  <h4 className="font-display font-black text-sm uppercase text-white tracking-widest">{lesson.title}</h4>
                  <p className="text-xs text-cs-gray leading-relaxed">{lesson.description}</p>
                  <div className="p-3 bg-cs-dark border border-cs-border/50 text-[10px] font-mono text-slate-300 rounded leading-relaxed">
                    <span className="text-cs-orange font-bold mr-1">ASSIGNMENT:</span> {lesson.assignment}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* bottom CTA summary bar */}
      <div className="bg-gradient-to-r from-cs-surface-light to-cs-dark border border-cs-border rounded-2xl p-6 md:p-10 flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="space-y-1.5 text-left md:max-w-xl">
          <h3 className="font-display font-black text-xl text-white uppercase tracking-wider">REBUILD YOUR BIOMECHANICS NOW</h3>
          <p className="text-xs text-cs-gray leading-relaxed">
            Gain immediate lifetime entry into all 4 stages of our course catalog, the verified students utility lineup maps, and our private tactical Discord group.
          </p>
        </div>
        <button
          onClick={() => onOpenCheckout('standard')}
          className="w-full md:w-auto px-6 py-3 bg-cs-orange text-white font-display font-black text-sm uppercase tracking-wider rounded shadow-lg hover:scale-103 active:scale-97 cursor-pointer transition-all shrink-0 glow-btn"
          id="overview-purchase-btn"
        >
          Secure Enrollment of $49.99
        </button>
      </div>

    </div>
  );
}
