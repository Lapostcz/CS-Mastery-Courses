/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Check, ShieldCheck, Sparkles, CreditCard, Award, ArrowRight } from 'lucide-react';

interface PricingPageProps {
  onOpenCheckout: (tier: 'standard' | 'pro') => void;
}

export default function PricingPage({ onOpenCheckout }: PricingPageProps) {
  
  const standardFeatures = [
    "Full lifetime access to all 4 video stages",
    "20+ comprehensive mechanical video lectures",
    "Actionable training checklists & homework",
    "Direct entry to our private Discord community",
    "Lifetime access to Mirage/DustII/Inferno lineups database",
    "30-day money back performance guarantee"
  ];

  const proFeatures = [
    "Everything included in the Standard Course",
    "1-hour private gameplay demo analysis with Coach Karr",
    "Personalized mechanical error scorecard",
    "Custom sensitivity and mouse parameters audit",
    "Priority support ticket channels inside Discord"
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-16 animate-fade-in" id="pricing-root">
      
      {/* Page Header */}
      <div className="text-center space-y-3 max-w-2xl mx-auto">
        <span className="text-xs font-mono text-cs-orange font-bold uppercase tracking-widest">[TUITION OPTIONS]</span>
        <h1 className="text-4xl md:text-5xl font-display font-black text-white uppercase tracking-wide">
          SIMPLE, HONEST PRICING
        </h1>
        <p className="text-sm text-cs-gray leading-relaxed font-sans text-slate-300">
          No monthly subscription traps. Pay once, secure your course files, study at your own pace, and unlock competitive gains with clear guarantees.
        </p>
      </div>

      {/* Two cards container */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
        
        {/* Card 1: Standard Syllabus */}
        <div className="bg-cs-surface border border-cs-border rounded-2xl p-6 md:p-8 space-y-8 relative overflow-hidden flex flex-col justify-between shadow-xl">
          <div className="space-y-6">
            <div className="space-y-1">
              <span className="text-xs font-mono font-semibold text-cs-orange uppercase">[STANDARD MODULES]</span>
              <h3 className="text-2xl font-display font-bold text-white uppercase tracking-wide">Standard Course</h3>
              <p className="text-xs text-cs-gray leading-relaxed font-sans">
                Perfect for solo self-studiers who want structured biomechanical instructions to systematically climb matchmaking ranks at their own pace.
              </p>
            </div>

            {/* Price Row */}
            <div className="py-4 border-y border-cs-border/50">
              <div className="flex items-baseline gap-2">
                <span className="text-4xl font-display font-black text-white">$49.99</span>
                <span className="text-xs text-cs-gray font-mono uppercase font-bold">one-time payment</span>
              </div>
              <p className="text-[10px] text-cs-gray font-mono mt-1">✓ Permanent access. No recurring charges.</p>
            </div>

            {/* Features checkmark */}
            <ul className="space-y-3">
              {standardFeatures.map((feat, idx) => (
                <li key={idx} className="flex items-start gap-2.5 text-xs text-slate-300 leading-tight">
                  <Check size={14} className="text-cs-orange shrink-0 mt-0.5" />
                  <span>{feat}</span>
                </li>
              ))}
            </ul>
          </div>

          <button
            onClick={() => onOpenCheckout('standard')}
            className="w-full py-3 bg-cs-border hover:bg-cs-orange hover:text-white text-white font-display font-black uppercase text-sm tracking-wider rounded-lg transition-all duration-200 cursor-pointer flex items-center justify-center gap-2"
            id="buy-standard-btn"
          >
            Enlist Standard — $49.99
            <ArrowRight size={14} />
          </button>
        </div>

        {/* Card 2: PRO Bundle */}
        <div className="bg-cs-surface border-2 border-cs-orange rounded-2xl p-6 md:p-8 space-y-8 relative overflow-hidden flex flex-col justify-between shadow-2xl">
          {/* Top visual micro banner */}
          <div className="absolute top-0 right-0 bg-cs-orange text-white font-mono font-bold text-[9px] uppercase tracking-widest px-4 py-1 rounded-bl">
            MOST POPULAR
          </div>

          <div className="space-y-6">
            <div className="space-y-1">
              <div className="flex items-center gap-1.5 text-cs-yellow">
                <Sparkles size={14} className="animate-pulse" />
                <span className="text-xs font-mono font-semibold uppercase">[PREMIUM ENVELOPE]</span>
              </div>
              <h3 className="text-2xl font-display font-bold text-white uppercase tracking-wide">Mastery Pro Bundle</h3>
              <p className="text-xs text-cs-gray leading-relaxed font-sans text-slate-200">
                Adds a premium private critique ticket. Paste a demo code of your choice, and of our verified coaches will trace your habits and output a personalized clinic feedback report.
              </p>
            </div>

            {/* Price Row */}
            <div className="py-4 border-y border-cs-border/50">
              <div className="flex items-baseline gap-2">
                <span className="text-4xl font-display font-black text-cs-yellow">$79.99</span>
                <span className="text-xs text-cs-gray font-mono uppercase font-bold">one-time payment</span>
              </div>
              <p className="text-[10px] text-cs-orange font-mono font-bold mt-1">★ Includes 1 Hour Private Coaching Sheet</p>
            </div>

            {/* Features checkmark */}
            <ul className="space-y-3">
              {proFeatures.map((feat, idx) => (
                <li key={idx} className="flex items-start gap-2.5 text-xs text-slate-300 leading-tight">
                  <Check size={14} className="text-cs-yellow shrink-0 mt-0.5" />
                  <span>{feat}</span>
                </li>
              ))}
            </ul>
          </div>

          <button
            onClick={() => onOpenCheckout('pro')}
            className="w-full py-3 bg-cs-orange text-white font-display font-extrabold uppercase text-sm tracking-wider rounded-lg transition-all shadow-lg hover:scale-102 duration-150 cursor-pointer glow-btn flex items-center justify-center gap-2"
            id="buy-pro-btn"
          >
            Secure Pro Bundle — $79.99
            <ArrowRight size={14} />
          </button>
        </div>

      </div>

      {/* Trust guarantees footer section */}
      <div className="border-t border-cs-border/50 max-w-3xl mx-auto pt-10 text-center space-y-6">
        <h4 className="font-mono text-xs text-cs-orange uppercase font-bold tracking-widest">TRANSACTION INTEGRITY ASSURED</h4>
        
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 text-xs text-slate-300">
          <div className="space-y-2 bg-cs-surface border border-cs-border/60 p-4 rounded-xl">
            <div className="w-10 h-10 rounded-full bg-cs-orange/10 flex items-center justify-center text-cs-orange mx-auto">
              <ShieldCheck size={18} />
            </div>
            <h5 className="font-bold text-white uppercase font-display text-sm">30-Day Guarantee</h5>
            <p className="text-[10px] text-cs-gray leading-relaxed">
              If your matchmaking rankings don't improve or you aren't satisfied, email us. We will issue a refund within 48 hours.
            </p>
          </div>

          <div className="space-y-2 bg-cs-surface border border-cs-border/60 p-4 rounded-xl">
            <div className="w-10 h-10 rounded-full bg-cs-orange/10 flex items-center justify-center text-cs-orange mx-auto">
              <CreditCard size={18} />
            </div>
            <h5 className="font-bold text-white uppercase font-display text-sm">Stripe Secure</h5>
            <p className="text-[10px] text-cs-gray leading-relaxed">
              We never store your payment data. Your checkout form passes credentials directly to Stripe via secure, encrypted tokens.
            </p>
          </div>

          <div className="space-y-2 bg-cs-surface border border-cs-border/60 p-4 rounded-xl">
            <div className="w-10 h-10 rounded-full bg-cs-orange/10 flex items-center justify-center text-cs-orange mx-auto">
              <Award size={18} />
            </div>
            <h5 className="font-bold text-white uppercase font-display text-sm">Private Community</h5>
            <p className="text-[10px] text-cs-gray leading-relaxed">
              No toxic, spam advertisers. Your welcome pack contains safe entry credentials directly into our curated student guild.
            </p>
          </div>
        </div>
      </div>

    </div>
  );
}
