/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { X, CreditCard, ShieldCheck, Mail, User, Sparkles, Check } from 'lucide-react';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedTier: 'standard' | 'pro';
  onPaymentSuccess: (name: string, email: string, tier: 'standard' | 'pro') => void;
}

export default function CheckoutModal({
  isOpen,
  onClose,
  selectedTier,
  onPaymentSuccess
}: CheckoutModalProps) {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    cardNumber: '4242 •••• •••• 4242',
    expiry: '12/28',
    cvc: '137',
    zip: '90210'
  });
  
  const [loadingStep, setLoadingStep] = useState<number>(-1); // -1: idle, 0+: steps
  const [errorMsg, setErrorMsg] = useState('');

  if (!isOpen) return null;

  const price = selectedTier === 'standard' ? '$49.99' : '$79.99';
  const title = selectedTier === 'standard' ? 'CS2 Mastery Standard Course' : 'CS2 Mastery Pro Bundle';

  const steps = [
    "Contacting secure payment servers...",
    "Authorizing charge with credit network...",
    "Creating lifetime student database ledger...",
    "Sending private Discord guild entry tokens...",
    "Deployment completed successfully!"
  ];

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim()) {
      setErrorMsg("Please enter your full name.");
      return;
    }
    if (!formData.email.trim() || !formData.email.includes('@')) {
      setErrorMsg("Please enter a valid email address.");
      return;
    }
    
    setErrorMsg('');
    setLoadingStep(0);

    // Dynamic terminal simulation
    const interval = setInterval(() => {
      setLoadingStep((prev) => {
        if (prev >= steps.length - 1) {
          clearInterval(interval);
          setTimeout(() => {
            onPaymentSuccess(formData.name, formData.email, selectedTier);
            onClose();
          }, 800);
          return prev;
        }
        return prev + 1;
      });
    }, 900);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-fade-in" id="checkout-modal">
      <div 
        className="relative w-full max-w-lg bg-cs-surface border border-cs-border rounded-xl overflow-hidden shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header decoration */}
        <div className="h-1.5 w-full bg-gradient-to-r from-cs-orange to-cs-yellow"></div>
        
        {/* Close Button */}
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 text-cs-gray hover:text-white transition-colors duration-200 p-1"
          id="close-checkout"
        >
          <X size={20} />
        </button>

        <div className="p-6 md:p-8">
          {loadingStep === -1 ? (
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <span className="text-xs uppercase tracking-widest text-cs-orange font-mono font-medium block mb-1">Secure Checkout</span>
                <h3 className="text-2xl font-display font-bold text-white tracking-wide uppercase">{title}</h3>
                <p className="text-sm text-cs-gray mt-1">
                  100% Secure 256-bit encrypted checkout proxy. Includes your 30-day performance refund guarantee.
                </p>
              </div>

              {/* Price summary */}
              <div className="bg-cs-surface-light border border-cs-border p-4 rounded-lg flex items-center justify-between">
                <div>
                  <div className="text-sm text-white font-medium">One-Time Enrollment</div>
                  <div className="text-xs text-cs-gray mt-0.5">Lifetime syllabus access + Discord guild</div>
                </div>
                <div className="text-2xl font-display font-bold text-cs-orange">{price}</div>
              </div>

              {errorMsg && (
                <div className="p-3 bg-red-950/40 border border-red-500/30 text-red-200 text-xs rounded-lg font-mono">
                  ERROR: {errorMsg}
                </div>
              )}

              {/* Input Forms */}
              <div className="space-y-4">
                {/* Name */}
                <div>
                  <label className="block text-xs uppercase font-mono tracking-wider text-cs-gray mb-1.5">Student Username (Full Name)</label>
                  <div className="relative">
                    <User className="absolute left-3 top-2.5 text-cs-gray" size={16} />
                    <input
                      type="text"
                      name="name"
                      required
                      placeholder="e.g. Nicholas 's1mple' Kovacs"
                      value={formData.name}
                      onChange={handleInputChange}
                      className="w-full pl-10 pr-4 py-2 bg-cs-dark border border-cs-border rounded-lg text-white font-medium placeholder-cs-gray/50 focus:outline-none focus:border-cs-orange text-sm transition-colors"
                    />
                  </div>
                </div>

                {/* Email */}
                <div>
                  <label className="block text-xs uppercase font-mono tracking-wider text-cs-gray mb-1.5 font-medium">E-mail Address (For Course Dashboard access)</label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-2.5 text-cs-gray" size={16} />
                    <input
                      type="email"
                      name="email"
                      required
                      placeholder="you@esportsmail.com"
                      value={formData.email}
                      onChange={handleInputChange}
                      className="w-full pl-10 pr-4 py-2 bg-cs-dark border border-cs-border rounded-lg text-white font-medium placeholder-cs-gray/50 focus:outline-none focus:border-cs-orange text-sm transition-colors"
                    />
                  </div>
                </div>

                {/* Card Elements Dummy */}
                <div>
                  <label className="block text-xs uppercase font-mono tracking-wider text-cs-gray mb-1.5 font-medium">Credit Card Details (Demo Stripe Setup)</label>
                  <div className="bg-cs-dark border border-cs-border rounded-lg p-3 space-y-3">
                    <div className="relative flex items-center">
                      <CreditCard className="absolute left-1 text-cs-gray" size={16} />
                      <input
                        type="text"
                        name="cardNumber"
                        required
                        placeholder="4242 4242 4242 4242"
                        value={formData.cardNumber}
                        onChange={handleInputChange}
                        className="w-full pl-7 pr-3 bg-transparent text-white font-mono text-sm focus:outline-none"
                      />
                      <span className="text-[10px] font-mono tracking-wider text-cs-orange bg-cs-orange/10 border border-cs-orange/20 px-1.5 py-0.5 rounded ml-2 shrink-0">STRIPE PROXY</span>
                    </div>

                    <div className="grid grid-cols-3 gap-3 pt-2 border-t border-cs-border/50">
                      <div>
                        <span className="text-[9px] font-mono text-cs-gray uppercase block mb-1">EXPIRY</span>
                        <input
                          type="text"
                          name="expiry"
                          required
                          placeholder="MM/YY"
                          value={formData.expiry}
                          onChange={handleInputChange}
                          className="w-full bg-transparent text-white font-mono text-xs focus:outline-none placeholder-cs-gray/30"
                        />
                      </div>
                      <div>
                        <span className="text-[9px] font-mono text-cs-gray uppercase block mb-1">CVC SECURITY</span>
                        <input
                          type="text"
                          name="cvc"
                          required
                          placeholder="3 digits"
                          value={formData.cvc}
                          onChange={handleInputChange}
                          className="w-full bg-transparent text-white font-mono text-xs focus:outline-none placeholder-cs-gray/30"
                        />
                      </div>
                      <div>
                        <span className="text-[9px] font-mono text-cs-gray uppercase block mb-1">ZIP POSTAL</span>
                        <input
                          type="text"
                          name="zip"
                          required
                          placeholder="90210"
                          value={formData.zip}
                          onChange={handleInputChange}
                          className="w-full bg-transparent text-white font-mono text-xs focus:outline-none placeholder-cs-gray/30"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                className="w-full py-3 bg-cs-orange text-white font-display font-extrabold uppercase text-lg tracking-wider hover:bg-cs-orange/95 active:scale-[0.98] transition-all rounded-lg shadow-lg flex items-center justify-center gap-2 glow-btn cursor-pointer"
                id="submit-payment"
              >
                <ShieldCheck size={20} />
                Authorize Payment of {price}
              </button>

              <div className="text-center font-mono text-[10px] text-cs-gray">
                By purchasing, you agree to our 30-day performance refund protocol.
              </div>
            </form>
          ) : (
            <div className="py-8 text-center space-y-6 font-mono">
              <div className="relative flex justify-center">
                <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-r-2 border-cs-orange border-b-transparent border-l-transparent"></div>
                <div className="absolute inset-0 flex items-center justify-center text-cs-orange font-bold text-lg">CS</div>
              </div>

              <div className="space-y-2">
                <span className="text-xs uppercase tracking-widest text-cs-orange">Secure Payment Terminal</span>
                <h4 className="text-xl font-display font-medium text-white uppercase">Processing Transaction...</h4>
              </div>

              <div className="bg-cs-dark border border-cs-border rounded-lg p-5 text-left text-xs max-w-sm mx-auto space-y-2.5 shadow-inner">
                {steps.map((step, idx) => {
                  const isCurrent = idx === loadingStep;
                  const isDone = idx < loadingStep;
                  return (
                    <div 
                      key={idx} 
                      className={`flex items-start gap-2.5 transition-opacity duration-300 ${
                        isCurrent ? "text-cs-yellow text-opacity-100 font-bold" : isDone ? "text-cs-green/80 text-opacity-80" : "text-cs-gray/40 text-opacity-40"
                      }`}
                    >
                      {isDone ? (
                        <Check size={14} className="mt-0.5 text-cs-green shrink-0" />
                      ) : isCurrent ? (
                        <div className="w-3.5 h-3.5 rounded-full border-2 border-cs-yellow border-t-transparent animate-spin shrink-0 mt-0.5"></div>
                      ) : (
                        <div className="w-1.5 h-1.5 rounded-full bg-cs-border shrink-0 mt-1.5"></div>
                      )}
                      <span className="leading-tight shrink">{step}</span>
                    </div>
                  );
                })}
              </div>

              <p className="text-[10px] text-cs-gray italic">
                Do not refresh this window. Secure protocol underway.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
