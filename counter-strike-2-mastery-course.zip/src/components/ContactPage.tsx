/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Send, MessageSquare, ExternalLink, HelpCircle, Check, Shield } from 'lucide-react';

export default function ContactPage() {
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    topic: 'Tuition Inquiry',
    message: ''
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [ticketDetails, setTicketDetails] = useState<{
    id: string;
    priority: string;
    estResponse: string;
  } | null>(null);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.username.trim() || !formData.email.trim() || !formData.message.trim()) return;

    setIsSubmitting(true);

    setTimeout(() => {
      setTicketDetails({
        id: `CS-0${Math.floor(100 + Math.random() * 900)}`,
        priority: formData.topic === 'Tuition Inquiry' ? 'CRITICAL - HIGH' : 'STANDARD',
        estResponse: formData.topic === 'Tuition Inquiry' ? 'Under 2 hours' : 'Under 6 hours'
      });
      setIsSubmitting(false);
    }, 1200);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-16 animate-fade-in" id="contact-root">
      
      {/* Header */}
      <div className="text-center space-y-3 max-w-2xl mx-auto">
        <span className="text-xs font-mono text-cs-orange font-bold uppercase tracking-widest">[SUPPORT CONTROL]</span>
        <h1 className="text-4xl md:text-5xl font-display font-black text-white uppercase tracking-wide">
          CONTACT ESPORTS DESK
        </h1>
        <p className="text-sm text-cs-gray leading-relaxed font-sans text-slate-300">
          Have an active team enquiry? Or experiencing issues copying your CS2 console files? Message our coordinators below.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 max-w-5xl mx-auto">
        
        {/* Left column: Ticket registration panel */}
        <div className="lg:col-span-7 bg-cs-surface border border-cs-border rounded-2xl p-6 md:p-8 space-y-6">
          
          {!ticketDetails ? (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <span className="text-xs font-mono text-cs-orange font-bold block uppercase mb-1">TRANSMISSION PORTAL</span>
                <h4 className="text-lg font-display font-black text-white uppercase tracking-wide">Draft Support Ticket</h4>
                <p className="text-xs text-cs-gray mt-1 leading-normal">
                  Inquiries concerning refund requests, bulk team registrations, or custom sponsorships are processed in highly isolated support queues.
                </p>
              </div>

              {/* inputs */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-mono uppercase text-cs-gray mb-1.5 font-medium">Your Nickname</label>
                  <input
                    type="text"
                    required
                    name="username"
                    placeholder="e.g. s1mple"
                    value={formData.username}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2.5 bg-cs-dark border border-cs-border rounded-lg text-white font-sans placeholder-cs-gray/30 focus:outline-none focus:border-cs-orange text-xs transition-colors"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-mono uppercase text-cs-gray mb-1.5 font-medium">Your E-mail</label>
                  <input
                    type="email"
                    required
                    name="email"
                    placeholder="s1mple@esports.com"
                    value={formData.email}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2.5 bg-cs-dark border border-cs-border rounded-lg text-white font-sans placeholder-cs-gray/30 focus:outline-none focus:border-cs-orange text-xs transition-colors"
                  />
                </div>
              </div>

              {/* Topic Select */}
              <div>
                <label className="block text-[10px] font-mono uppercase text-cs-gray mb-1.5 font-medium">Topic Department</label>
                <select
                  name="topic"
                  value={formData.topic}
                  onChange={handleInputChange}
                  className="w-full px-4 py-2.5 bg-cs-dark border border-cs-border rounded-lg text-white font-sans focus:outline-none focus:border-cs-orange text-xs transition-colors"
                >
                  <option value="Tuition Inquiry">Tuition Payment & Registration</option>
                  <option value="Config Bug">Steam console files and Binds issues</option>
                  <option value="Coaching Booking">Pro gameplay demo schedules</option>
                  <option value="Sponsorship">Bulk Team discounts</option>
                </select>
              </div>

              {/* Message */}
              <div>
                <label className="block text-[10px] font-mono uppercase text-cs-gray mb-1.5 font-medium">Your detailed message</label>
                <textarea
                  rows={4}
                  required
                  name="message"
                  placeholder="Include your matchmaking rank details or transaction ID if relevant..."
                  value={formData.message}
                  onChange={handleInputChange}
                  className="w-full px-4 py-2.5 bg-cs-dark border border-cs-border rounded-lg text-white font-sans placeholder-cs-gray/30 focus:outline-none focus:border-cs-orange text-xs transition-colors resize-none"
                />
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-3 bg-cs-orange text-white font-display font-extrabold uppercase text-sm tracking-widest rounded-lg hover:bg-cs-orange/90 transition-all flex items-center justify-center gap-2 cursor-pointer"
                id="submit-contact"
              >
                <Send size={14} />
                {isSubmitting ? "Transmitting Feed..." : "Register Ticket"}
              </button>
            </form>
          ) : (
            /* Resolved Ticket styling */
            <div className="space-y-6 text-center py-6 animate-fade-in font-mono">
              <div className="w-14 h-14 rounded-full bg-cs-green/10 border border-cs-green/30 text-cs-green flex items-center justify-center mx-auto text-xl">
                ✓
              </div>
              
              <div className="space-y-1.5">
                <span className="text-[10px] text-cs-orange font-bold uppercase tracking-widest">TRANSMISSION SECURED</span>
                <h4 className="text-xl font-display font-black text-white uppercase tracking-wide">Support Ticket Drafted</h4>
                <p className="text-xs text-cs-gray max-w-sm mx-auto font-sans">
                  Your ticket has been written into our support queue. A copy of this secure receipt has been routed index-side to <span className="text-white font-mono">{formData.email}</span>.
                </p>
              </div>

              {/* Ticket table representation */}
              <div className="bg-cs-dark border border-cs-border rounded-lg p-5 text-left max-w-sm mx-auto text-xs space-y-2.5">
                <div className="flex justify-between border-b border-cs-border/40 pb-2">
                  <span className="text-cs-gray uppercase">Ticket Code:</span>
                  <span className="text-white font-bold">{ticketDetails.id}</span>
                </div>
                <div className="flex justify-between border-b border-cs-border/40 pb-2">
                  <span className="text-cs-gray uppercase">Queue Department:</span>
                  <span className="text-white">{formData.topic}</span>
                </div>
                <div className="flex justify-between border-b border-cs-border/40 pb-2">
                  <span className="text-cs-gray uppercase">Queue priority:</span>
                  <span className="text-cs-yellow font-bold uppercase">{ticketDetails.priority}</span>
                </div>
                <div className="flex justify-between pt-1">
                  <span className="text-cs-gray uppercase">Est. Response Time:</span>
                  <span className="text-cs-green font-bold">{ticketDetails.estResponse}</span>
                </div>
              </div>

              <p className="text-[9px] text-cs-gray italic leading-normal max-w-xs mx-auto">
                No need to submit multiple drafts. Our coordinators monitor incoming tickets in real-time.
              </p>

              <button
                onClick={() => setTicketDetails(null)}
                className="px-4 py-2 bg-cs-border hover:bg-cs-orange text-white text-[10px] font-mono tracking-wider uppercase rounded cursor-pointer transition-colors"
              >
                Draft New Support Ticket
              </button>
            </div>
          )}

        </div>

        {/* Right column: Discord community info */}
        <div className="lg:col-span-5 space-y-6 flex flex-col justify-between">
          <div className="bg-cs-surface border border-cs-border rounded-2xl p-6 md:p-8 space-y-6">
            <div className="space-y-1">
              <span className="text-xs font-mono text-[#5865F2] font-semibold uppercase block">COMMUNITY INVITE</span>
              <h4 className="text-xl font-display font-bold text-white uppercase tracking-wide flex items-center gap-2">
                <MessageSquare size={18} /> Community Discord
              </h4>
              <p className="text-xs text-cs-gray leading-relaxed text-slate-300">
                You don't need to be an active student to inspect our public discussion channels! Join over 2,400+ competitive gamers talking tactics, settings, maps, and coaching times.
              </p>
            </div>

            <div className="bg-cs-dark border border-cs-border/50 rounded-lg p-5 font-mono text-xs text-slate-300 space-y-3">
              <div className="flex justify-between text-[11px] border-b border-cs-border/30 pb-2">
                <span>Active Members:</span>
                <span className="text-cs-green font-bold">2,482 Cadets</span>
              </div>
              <div className="flex justify-between text-[11px] border-b border-cs-border/30 pb-2">
                <span>Direct Active Online:</span>
                <span className="text-white font-bold flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-cs-green animate-pulse"></span> 248 Online
                </span>
              </div>
              <div className="text-[10px] text-cs-gray leading-normal">
                ✓ Public strategy chats<br />
                ✓ Public workshop map suggestions<br />
                ✓ Client parameters configs support
              </div>
            </div>

            <a 
              href="https://discord.gg"
              target="_blank"
              rel="noreferrer"
              className="w-full py-3 bg-[#5865F2] hover:bg-[#4752C4] text-white font-display font-extrabold text-xs uppercase text-center tracking-widest rounded-lg shadow-lg flex items-center justify-center gap-2"
              id="sidebar-discord-btn"
            >
              Copy Public Discord Code
              <ExternalLink size={14} />
            </a>
          </div>

          {/* Secure disclaimer box */}
          <div className="p-4 border border-cs-border/50 bg-cs-dark/20 rounded-xl space-y-2 flex items-start gap-3">
            <Shield className="text-cs-yellow mt-0.5 shrink-0" size={18} />
            <div className="space-y-1">
              <span className="text-[10px] font-mono text-white font-bold uppercase leading-none block">Spam Mitigation Safeguard</span>
              <p className="text-[10px] text-cs-gray leading-relaxed">
                Our support portals are protected by cloud shields. Spam drafts containing duplicate match IDs or random links will trigger automated IP restrictions.
              </p>
            </div>
          </div>
        </div>

      </div>

    </div>
  );
}
