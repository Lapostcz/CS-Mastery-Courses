/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Lesson {
  id: string;
  title: string;
  description: string;
  duration: string; // e.g. "18 min"
  category: 'aim' | 'movement' | 'utility' | 'economy' | 'teamplay' | 'mindset';
  videoUrl: string; // simulated or real YouTube/Vimeo embed
  vimeoPlaceholderId?: string;
  assignment: string;
  practicalActivity: string;
}

export interface Week {
  weekNumber: number;
  title: string;
  subtitle: string;
  description: string;
  lessons: Lesson[];
}

export interface Instructor {
  id: string;
  name: string;
  nickname: string;
  role: string;
  avatar: string;
  bio: string;
  yearsOfExp: number;
  stats: {
    faceitLevel: number;
    elo: number;
    winRate: string;
    averageKDR: string;
  };
  specialty: string;
  coachQuote: string;
}

export interface Testimonial {
  id: string;
  name: string;
  text: string;
  date: string;
  oldRank: string;
  newRank: string;
  oldRankIcon: string;
  newRankIcon: string;
  isVerified: boolean;
}

export interface FAQItem {
  id: string;
  question: string;
  answer: string;
  category: 'payment' | 'course' | 'schedule' | 'coaching';
}

export interface UtilityLineup {
  id: string;
  map: 'Mirage' | 'Inferno' | 'Dust II' | 'Nuke' | 'Anubis' | 'Ancient';
  side: 'T' | 'CT';
  name: string;
  type: 'Smoke' | 'Flash' | 'Molly';
  target: string; // e.g. "A Site Stairs"
  description: string;
  videoSimulatorUrl?: string; // Clip url
  lineupVideoUrl?: string; // YouTube/video url or embed
  crosshairPlace: string; // Where to aim
  standSpot: string; // Where to stand
  throwType: 'Left Click' | 'Jump Throw' | 'Run Throw' | 'Right Click';
}

export interface StudentEnrollment {
  id: string;
  name: string;
  email: string;
  tier: 'standard' | 'pro';
  enrolledAt: string;
  completedLessons: string[]; // lesson IDs
  submittedDemoUrl?: string;
  submittedDemoStatus?: 'pending' | 'reviewed';
  demoReviewResult?: string;
}
