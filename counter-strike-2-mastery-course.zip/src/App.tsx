/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import LandingPage from './components/LandingPage';
import CourseOverviewPage from './components/CourseOverviewPage';
import InstructorsPage from './components/InstructorsPage';
import PricingPage from './components/PricingPage';
import FAQPage from './components/FAQPage';
import ContactPage from './components/ContactPage';
import CheckoutModal from './components/CheckoutModal';
import StudentPortal from './components/StudentPortal';
import { StudentEnrollment } from './types';
import { Sparkles, Trophy, X, ChevronRight, Play } from 'lucide-react';

export default function App() {
  const [activeView, setActiveView] = useState<string>('home');
  const [enrollment, setEnrollment] = useState<StudentEnrollment | null>(null);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState<boolean>(false);
  const [checkoutTier, setCheckoutTier] = useState<'standard' | 'pro'>('standard');
  const [alertMsg, setAlertMsg] = useState<{ text: string; type: 'success' | 'info' | 'warn' } | null>(null);

  // Check LocalStorage on boot to retrieve persistent student records
  useEffect(() => {
    const saved = localStorage.getItem('cs2_student_enrollment');
    if (saved) {
      try {
        setEnrollment(JSON.parse(saved));
        setAlertMsg({
          text: "Retrieved saved student session from local ledger.",
          type: "info"
        });
      } catch (e) {
        localStorage.removeItem('cs2_student_enrollment');
      }
    }
  }, []);

  // Save student data helper
  const saveEnrollment = (data: StudentEnrollment | null) => {
    setEnrollment(data);
    if (data) {
      localStorage.setItem('cs2_student_enrollment', JSON.stringify(data));
    } else {
      localStorage.removeItem('cs2_student_enrollment');
    }
  };

  // Open the simulated checkout element
  const handleOpenCheckout = (tier: 'standard' | 'pro') => {
    setCheckoutTier(tier);
    setIsCheckoutOpen(true);
  };

  // Process a successful authorized simulated purchase
  const handlePaymentSuccess = (name: string, email: string, tier: 'standard' | 'pro') => {
    const freshEnrollment: StudentEnrollment = {
      id: `student-${Math.floor(100000 + Math.random() * 900000)}`,
      name: name,
      email: email,
      tier: tier,
      enrolledAt: new Date().toISOString(),
      completedLessons: []
    };

    saveEnrollment(freshEnrollment);
    setActiveView('student-portal');
    setAlertMsg({
      text: `CONGRATULATIONS! Your enrollment in the ${tier === 'pro' ? 'Pro Bundle' : 'Standard Course'} has been secured! Explore your 4-week dashboard.`,
      type: "success"
    });
  };

  // Simulate GUEST Sandbox Account
  const handleSimulateSandbox = () => {
    const sandboxUser: StudentEnrollment = {
      id: 'student-sandbox-demo-999',
      name: 'Major Ronald "Cadet" Miller',
      email: 'sandbox@cs2masterclass.com',
      tier: 'pro',
      enrolledAt: new Date().toISOString(),
      completedLessons: ['w1-l1', 'w1-l2'], // Pre-complete standard aim classes
      submittedDemoUrl: 'STEAM_CS2_SAMPLE_DEMO_MATCH_CODE_KINETICS',
      submittedDemoStatus: 'reviewed',
      demoReviewResult: `COACH PRE-LOADED REPORT — SANDBOX MODE MODEL
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Reviewer: Dmitri 'Vortex' Rostov
Target Match: Sample Mirage Performance

CRITICAL FLASHLIGHT HABIT DETECTED:
- Spray Pattern: You crouched at round 5 while firing from Palace, giving up height.
REMEDY: Keep strafe patterns active on long angles. Reduce mouse sensitivity from 2.4 to 1.1 immediately to restrict rotational jitter.`
    };

    saveEnrollment(sandboxUser);
    setActiveView('student-portal');
    setAlertMsg({
      text: "SANDBOX MODE ENGAGED: Simulated premium Pro account is now active to preview inside the student dashboard!",
      type: "success"
    });
  };

  // Process student upgrade to Pro tier inside portal
  const handleUpgradeToPro = () => {
    if (enrollment) {
      const upgraded: StudentEnrollment = {
        ...enrollment,
        tier: 'pro'
      };
      saveEnrollment(upgraded);
      setAlertMsg({
        text: "UPGRADE SECURED: Account tier upgraded to Pro. Live matchmaking demo critique tools are now unlocked!",
        type: "success"
      });
    }
  };

  // Terminate simulation session
  const handleLogout = () => {
    saveEnrollment(null);
    setActiveView('home');
    setAlertMsg({
      text: "Simulated curriculum session successfully signed off.",
      type: "info"
    });
  };

  return (
    <div className="min-h-screen bg-cs-dark text-cs-light flex flex-col justify-between" id="app-root">
      
      {/* Upper Navigation Header */}
      <Navbar 
        activeView={activeView}
        setActiveView={setActiveView}
        enrollment={enrollment}
        onLogout={handleLogout}
        onSimulateSandbox={handleSimulateSandbox}
        onOpenCheckout={handleOpenCheckout}
      />

      {/* Floating alert banner for states */}
      {alertMsg && (
        <div className={`border-b px-4 py-3 text-xs font-mono text-center flex items-center justify-center gap-3 relative transition-all animate-fade-in ${
          alertMsg.type === 'success' ? 'bg-cs-green/10 border-cs-green/30 text-cs-green' :
          alertMsg.type === 'warn' ? 'bg-red-950/20 border-red-500/30 text-red-300' :
          'bg-cs-surface-light border-cs-border text-cs-yellow'
        }`} id="state-notification-ribbon">
          <div className="flex items-center gap-2">
            <span className="shrink-0 font-bold uppercase">
              {alertMsg.type === 'success' ? '[DEPLOY_OK]' : '[SYSTEM_INFO]'}
            </span>
            <span className="leading-tight">{alertMsg.text}</span>
          </div>
          
          <button 
            onClick={() => setAlertMsg(null)}
            className="absolute right-4 top-2 text-cs-gray hover:text-white transition-colors duration-150 p-1"
          >
            <X size={14} />
          </button>
        </div>
      )}

      {/* Primary Content Router */}
      <main className="flex-grow">
        {activeView === 'home' && (
          <LandingPage 
            onOpenCheckout={handleOpenCheckout}
            onSimulateSandbox={handleSimulateSandbox}
            setActiveView={setActiveView}
          />
        )}
        
        {activeView === 'curriculum' && (
          <CourseOverviewPage 
            onOpenCheckout={handleOpenCheckout}
          />
        )}
        
        {activeView === 'coaches' && (
          <InstructorsPage 
            onOpenCheckout={handleOpenCheckout}
          />
        )}
        
        {activeView === 'pricing' && (
          <PricingPage 
            onOpenCheckout={handleOpenCheckout}
          />
        )}

        {activeView === 'faq' && (
          <FAQPage />
        )}

        {activeView === 'contact' && (
          <ContactPage />
        )}

        {activeView === 'student-portal' && enrollment && (
          <StudentPortal 
            enrollment={enrollment}
            onUpdateEnrollment={saveEnrollment}
            onUpgradeToPro={handleUpgradeToPro}
          />
        )}
      </main>

      {/* Stripe secure checkout modal layer */}
      <CheckoutModal 
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
        selectedTier={checkoutTier}
        onPaymentSuccess={handlePaymentSuccess}
      />

      {/* Bottom Footer block */}
      <footer className="bg-cs-dark border-t border-cs-border py-12 px-4 sm:px-6 lg:px-8 mt-12">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="text-center md:text-left space-y-2">
            <div className="font-display font-black text-white text-base tracking-widest uppercase">
              CS MASTERY HUB
            </div>
            <p className="text-[10px] font-mono text-cs-gray">
              © 2026 Counter-Strike 2 Academy. This education project is an independent esports coaching portal. All game graphics and properties represent Valve Corporation.
            </p>
          </div>

          <div className="font-mono text-[10px] text-cs-gray text-center md:text-right space-y-1">
            <div className="flex gap-4 items-center justify-center md:justify-end">
              <button onClick={() => setActiveView('home')} className="hover:text-cs-orange">Landing Phase</button>
              <span>•</span>
              <button onClick={() => setActiveView('faq')} className="hover:text-cs-orange">FAQs</button>
              <span>•</span>
              <button onClick={() => setActiveView('contact')} className="hover:text-cs-orange">Help Desk Office</button>
            </div>
            <div className="italic">
              LATENCY METRICS: 14 SECONDS SYNC // SECURE 256-BIT
            </div>
          </div>
        </div>
      </footer>

    </div>
  );
}
