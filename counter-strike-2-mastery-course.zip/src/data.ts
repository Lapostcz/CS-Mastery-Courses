/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Week, Instructor, Testimonial, FAQItem, UtilityLineup } from './types';

export const weeksData: Week[] = [
  {
    weekNumber: 1,
    title: "Foundations & Aim Mechanics",
    subtitle: "Rebuild your mechanical baseline for CS2",
    description: "Master the fundamental physics of Counter-Strike 2. Perfect your mouse parameters, optimize system layout for maximum tick rate responsiveness, and drill your muscle memory to unlock pixel-perfect precision.",
    lessons: [
      {
        id: "w1-l1",
        title: "CS2 Engine Physics & Sens Calibration",
        description: "Configure absolute tracking, find your true DPI and 360-degree rotation index, and eliminate sub-optimal raw mouse input lag.",
        duration: "22 min",
        category: "aim",
        videoUrl: "https://www.youtube.com/embed/gI8g6f9RoxE", // Reference guides or stylized premium layout
        assignment: "Adjust sensitivity using the eDPI formula. Complete a 180-degree swipe test 20 times to confirm muscle memory consistency.",
        practicalActivity: "Target eDPI between 700 and 1100. Write down your exact parameters in your training journal."
      },
      {
        id: "w1-l2",
        title: "Crosshair Placement & Preshot Pathing",
        description: "Align your cursor to head level at all times using visual anchoring, corner slicing, and predictable path tracing.",
        duration: "18 min",
        category: "aim",
        videoUrl: "https://www.youtube.com/embed/fAEP6pndI0A",
        assignment: "Play 10 minutes of Prefire maps in Mirage. Focus entirely on keeping the crosshair exactly at standard counter-terrorist head level.",
        practicalActivity: "Verify 'Prefire Accuracy' statistics. Aim for 80%+ immediate pre-aim on common angles."
      },
      {
        id: "w1-l3",
        title: "Kinetic Movement: Counter-Strafing",
        description: "Learn how to arrest velocity instantly with counter-inputs ('A' and 'D') to achieve perfect accuracy the fraction of a second you fire.",
        duration: "25 min",
        category: "movement",
        videoUrl: "https://www.youtube.com/embed/gI8g6f9RoxE",
        assignment: "In the practice range, fire a single bullet while moving, but only after releasing the key and typing the opposite key.",
        practicalActivity: "Use `cl_showpos 1` to confirm speed drops to exactly 0 immediately prior to trigger squeeze."
      },
      {
        id: "w1-l4",
        title: "Recoil Pattern Mechanics & Spray Transfers",
        description: "Deconstruct the AK-47, M4A4, and M4A1-S seed patterns. Learn kinetic spray control up to 15 bullets and transition between targets.",
        duration: "30 min",
        category: "aim",
        videoUrl: "https://www.youtube.com/embed/fAEP6pndI0A",
        assignment: "Perform 100 successful 10-bullet spray controls on a wall at 15 meters, keeping the bullet cluster inside a tight 10cm circle.",
        practicalActivity: "Complete the Recoil Master map workshop challenges on 3 different rifles."
      },
      {
        id: "w1-l5",
        title: "Advanced Peeking: Jiggle vs. Wide Ferrari Peeks",
        description: "When to manipulate opponent latency. Execute rapid shoulder peeks for info, crouch slide peeks, and wide-swings around covers.",
        duration: "19 min",
        category: "movement",
        videoUrl: "https://www.youtube.com/embed/gI8g6f9RoxE",
        assignment: "Use dry-runs on active servers to practice jiggling common sniper lanes without exposing more than your left shoulder arm.",
        practicalActivity: "Deduce enemy awp location using baiting technique; document 5 successful baits."
      }
    ]
  },
  {
    weekNumber: 2,
    title: "Tactical Utility & Map Domination",
    subtitle: "Control the map using line-of-sight denying executes",
    description: "CS2 is a game of territory. If you don't know your utility lineups, you are giving away the map. This week, master standard meta smokes, molotovs, and popcorn pop-flashes for Mirage, Dust II, and Inferno.",
    lessons: [
      {
        id: "w2-l1",
        title: "The Ultimate Mirage Execute Suite",
        description: "Perfect details for Smoke A-Stairs, A-Cab, Jungle, and CT Spawn. Coordinate jump-throw bindings using standard CS2 console techniques.",
        duration: "27 min",
        category: "utility",
        videoUrl: "https://www.youtube.com/embed/fAEP6pndI0A",
        assignment: "Complete A Execute dry-runs on Mirage solo server. Throw Stairs, Jungle, CT smokes in sequence under 15 seconds.",
        practicalActivity: "Set up the local server with cheats allowed to visual trace utility flight paths with sv_grenade_trajectory_prac-1."
      },
      {
        id: "w2-l2",
        title: "Dust II B-Hold and Mid Control Utility",
        description: "How to crush aggressive Mid CT pushes. Learn Xbox smokes from T Spawn, B-door flashes, and retake denial techniques.",
        duration: "21 min",
        category: "utility",
        videoUrl: "https://www.youtube.com/embed/gI8g6f9RoxE",
        assignment: "Launch Dust II. Practice throwing B-tunnel pop flashes that detonate directly behind the door frame to blind defenders without flashing your entries.",
        practicalActivity: "Assess timing of Mid CT push and map out custom counter-utility."
      },
      {
        id: "w2-l3",
        title: "Inferno Banana Control & CT Retake Flows",
        description: "Secure the most heavily contested lane in competitive CS. Learn deep CT molotovs, banana retention nades, and quick A-site retakes.",
        duration: "26 min",
        category: "utility",
        videoUrl: "https://www.youtube.com/embed/fAEP6pndI0A",
        assignment: "Perform CT-side delay blocks on Banana. Cycle Molotov, Frag, and Smoke with a teammate to delay the T-rush by a full 45 seconds.",
        practicalActivity: "Create a mock delay ledger with timestamp entries."
      },
      {
        id: "w2-l4",
        title: "The Pop-Flash Masterclass: Kinetic Blinding",
        description: "Stop throwing flashes that enemies can see coming. Mastery of dynamic pop flashes designed to explode with zero visual warning.",
        duration: "20 min",
        category: "utility",
        videoUrl: "https://www.youtube.com/embed/gI8g6f9RoxE",
        assignment: "Find and save 3 custom flash lineups that bounce off map assets to surprise enemies hiding in standard default angles.",
        practicalActivity: "Test flash detonation points using localized server debug tools."
      }
    ]
  },
  {
    weekNumber: 3,
    title: "Team Play, Roles & Economy Masterclass",
    subtitle: "Play clean team CS and manipulate match momentum",
    description: "Fragging is only half the battle. CS2 is won on coordinated executes, trade killing structures, and strategic manipulation of the match economy.",
    lessons: [
      {
        id: "w3-l1",
        title: "Understanding Roles: Entry, Support, AWP & Lurk",
        description: "Identify your playstyle profile. Study specialized entry routes, support spacing, passive/aggressive AWping, and late-round lurking.",
        duration: "24 min",
        category: "teamplay",
        videoUrl: "https://www.youtube.com/embed/fAEP6pndI0A",
        assignment: "Analyze 2 professional demos (HLTV) of a player representing your target role. Note down their positioning map-by-map.",
        practicalActivity: "Write a 3-paragraph executive summary detailing how the pro played during retake clusters."
      },
      {
        id: "w3-l2",
        title: "Trade Spacing and Retake Chemistry",
        description: "How to bait and switch safely. Learn distance management so you can instantly avenge an entry-fragged teammate within 1.5 seconds.",
        duration: "20 min",
        category: "teamplay",
        videoUrl: "https://www.youtube.com/embed/gI8g6f9RoxE",
        assignment: "In premium matchmaking, identify teammate push patterns. Accompany them closely (spaced 4 meters) and practice trading instantly on contacts.",
        practicalActivity: "Capture at least 3 clips of clean trade frags where the teammate was avenged in under 2 seconds."
      },
      {
        id: "w3-l3",
        title: "CS2 Economy Calculus & Round Management",
        description: "When to full save, eco, force buy, or half buy. Read enemy loss bonuses, isolate weak economy setups, and make team calls.",
        duration: "22 min",
        category: "economy",
        videoUrl: "https://www.youtube.com/embed/fAEP6pndI0A",
        assignment: "Create a cheat sheet of loss bonuses for CT and T side after consecutive rounds lost. Memorize exact purchase threshold limits.",
        practicalActivity: "Run a team buy meeting during a live warm-up to practice calling the team purchase strategy."
      },
      {
        id: "w3-l4",
        title: "Communicating Tactics Under High-Pressure",
        description: "Structure clear calls. Eliminate filler panic words. Transmit precise spatial coordinates, health context, and team reposition requests.",
        duration: "18 min",
        category: "teamplay",
        videoUrl: "https://www.youtube.com/embed/gI8g6f9RoxE",
        assignment: "Record your own voice audio during a premade game. Circle each voice call that was descriptive rather than reactive or emotional.",
        practicalActivity: "Achieve 90%+ precise call index during aggressive site defense rounds."
      }
    ]
  },
  {
    weekNumber: 4,
    title: "Ranked Mindset, Demos & Climbing Loop",
    subtitle: "Overcome physical and mental walls to secure Faceit Level 10",
    description: "Mental fortitude separates the good from the great. Develop a rigid feedback loop, study your failures through intensive demo review, and eradicate tilt.",
    lessons: [
      {
        id: "w4-l1",
        title: "Self-Demo Diagnostics: Finding Structural Leaks",
        description: "Stop watching your highlight frags. Analyze each death, missed utility, bad spacing, and positioning fault systematically.",
        duration: "28 min",
        category: "mindset",
        videoUrl: "https://www.youtube.com/embed/fAEP6pndI0A",
        assignment: "Analyze a demo of a game you lost badly. Categorize every death into: Mechanical fail, Positional fail, Lack of Utility, or Bad Decs.",
        practicalActivity: "Create a death distribution table to find your single biggest gameplay leak."
      },
      {
        id: "w4-l2",
        title: "Eradicating Ranked Tilt & Mental Hardiness",
        description: "The psychology of flow. Learn neurological cooling cues, how to handle toxic lobbies, and reset focus after catastrophic rounds.",
        duration: "19 min",
        category: "mindset",
        videoUrl: "https://www.youtube.com/embed/gI8g6f9RoxE",
        assignment: "Apply the 'Tactical Respiration' protocol during your next high-stress matchmaking round. Avoid talking back to agitated teammates completely.",
        practicalActivity: "Maintain a positive chat response ledger for 5 matches in a row."
      },
      {
        id: "w4-l3",
        title: "Warmup Routines & Pre-Match Primer Protocols",
        description: "A professional 15-minute warmup sequence consisting of reflex training, local movement checks, spray calibration, and hand stretches.",
        duration: "16 min",
        category: "aim",
        videoUrl: "https://www.youtube.com/embed/fAEP6pndI0A",
        assignment: "Perform the structured 15-min warm-up sequence every day for a week. Document consistency in initial matchmaking rounds.",
        practicalActivity: "Compare first-half match K/D ration before and after utilizing the warm-up protocol."
      },
      {
        id: "w4-l4",
        title: "Statistics Integration & The Performance Loop",
        description: "How to inspect and read CS2 stats portals (Leetify/CS Stats) to modify your daily practice drills based on hard gameplay analytics.",
        duration: "25 min",
        category: "mindset",
        videoUrl: "https://www.youtube.com/embed/gI8g6f9RoxE",
        assignment: "Identify your 3 worst map win ratios. Plan a 10-day remediation routine focusing exclusively on those problematic environments.",
        practicalActivity: "Re-analyze your analytical statistics after 10 days of targeted map remediation."
      }
    ]
  }
];

export const instructorsData: Instructor[] = [
  {
    id: "coach-karr",
    name: "Alex 'Karr' Vance",
    nickname: "Karr",
    role: "Lead Strategist & Former Pro Coach",
    avatar: "https://images.unsplash.com/photo-1566492031773-4f4e44671857?q=80&w=400&h=400&fit=crop",
    bio: "Ex-competitor and analytical strategist who coached multiple Tier-2 professional teams in Europe. Vance specializes in map mechanics, tactical execute design, and coordinate system callouts.",
    yearsOfExp: 11,
    stats: {
      faceitLevel: 10,
      elo: 3250,
      winRate: "64.2%",
      averageKDR: "1.34"
    },
    specialty: "Macro Strategy, Demo Diagnostics, and Utility Spacing",
    coachQuote: "Counter-Strike is a chess game played at 240 frames per second. If you rely purely on aim, you will lose to those who know how to tilt the board in their favor."
  },
  {
    id: "coach-shroud",
    name: "Dmitri 'Vortex' Rostov",
    nickname: "Vortex",
    role: "Aim Specialist & Kinetic Mechanics Driller",
    avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?q=80&w=400&h=400&fit=crop",
    bio: "A legendary Faceit Level 10 pug-star who holds records in precision tracking. Rostov spent 5 years researching mechanical sensitivity and input dynamics to create the ultimate aim-warmup drill system.",
    yearsOfExp: 9,
    stats: {
      faceitLevel: 10,
      elo: 2980,
      winRate: "59.8%",
      averageKDR: "1.48"
    },
    specialty: "Spray Control, Reaction Slicing, and Kinetic Strafing",
    coachQuote: "Sens consistency is not a natural talent. It is structural reinforcement. Once your hardware is set correctly and path mechanics are automated, you do not miss."
  }
];

export const testimonialsData: Testimonial[] = [
  {
    id: "testi-1",
    name: "Marcus 'Cynic' Thompson",
    text: "I was hardstuck Gold Nova 2 for nearly 14 months. Every ranked lobby felt toxic, and my aim felt wild and hot-headed. Week 1 sensitivity calibration and Weeks 2 utility executions literally blew my mind. Within three weeks after completion, I went from MG1 straight to Supreme. Absolutely insane value.",
    date: "2026-03-12",
    oldRank: "Gold Nova II",
    newRank: "Master Guardian Elite",
    oldRankIcon: "GN2",
    newRankIcon: "MGE",
    isVerified: true
  },
  {
    id: "testi-2",
    name: "Sarah 'Valkyrie' Jensen",
    text: "As an AWPer, I struggled with positional awareness and trading spacing. Karr's support lectures guided me to understand CT-delays and spacing. My Faceit ELO skyrocketed from level 5 (1200) to level 9 (1850) in just a month! This isn't generic Youtube guides; this is structured, university-grade material.",
    date: "2026-04-05",
    oldRank: "Faceit Level 5",
    newRank: "Faceit Level 9",
    oldRankIcon: "L5",
    newRankIcon: "L9",
    isVerified: true
  },
  {
    id: "testi-3",
    name: "Hassan 'Razer' Al-Fayed",
    text: "I purchased the Pro package with the 1-hour private review. Vortex looked at my Mirage custom demo and instantly diagnosed that I was crouch-spraying way too early, which let enemies track my head. Fixing that one physical bad habit completely transformed my dueling stats.",
    date: "2026-05-10",
    oldRank: "Silver Master Elite",
    newRank: "Gold Nova Master",
    oldRankIcon: "SME",
    newRankIcon: "GNM",
    isVerified: true
  }
];

export const faqData: FAQItem[] = [
  {
    id: "faq-1",
    question: "Do I need any special hardware or high-tier GPU to enroll?",
    answer: "Absolutely not. While higher frame rates (144Hz+) are helpful for competitive CS2, our Week 1 includes instructions on how to optimize your client parameters, optimize settings, and maximize input latency responsiveness regardless of whether you have a premium rig or a standard laptop.",
    category: "course"
  },
  {
    id: "faq-2",
    question: "How does the course unlock process work?",
    answer: "To ensure maximum learning retention and prevent cognitive overload, the course lessons open week by week starting from your date of signup. Week 1 is available instantly. Week 2 opens after 7 days, Week 3 after 14 days, and Week 4 after 21 days. However, all utility databases and community forums are unlocked on day one!",
    category: "schedule"
  },
  {
    id: "faq-3",
    question: "Is there a real refund guarantee in case I don't rank up?",
    answer: "Yes, we offer a 100% 30-Day Money-Back Guarantee. If you fully watch the lectures, complete the quick homework worksheets, and still do not see a tangible improvement in your aim consistency or matchmaking statistics, simply contact support. We will issue a prompt refund, no questions asked.",
    category: "payment"
  },
  {
    id: "faq-4",
    question: "What is the key difference between the Standard and Pro bundles?",
    answer: "The Standard Course ($49.99) includes permanent lifetime access to all 4-weeks of premium structured video lectures, assignments, and the tactical Discord group. The Pro Bundle ($79.99) adds an exclusive 1-hour private gameplay demo analysis with Coach Karr, where we record video detailing your mechanical leaks, bad angles, and suggest custom sensitivity modifications.",
    category: "coaching"
  },
  {
    id: "faq-5",
    question: "How do I access the Private Discord community?",
    answer: "Upon successful checkout, you will receive an automated invitation link both in your dashboard and via the welcome email. The Private Discord contains rank-specific strategy channels, custom pre-fire map downloads, and allows you to find mature, non-toxic players the same rank to climb together.",
    category: "course"
  }
];

export const utilityDatabase: UtilityLineup[] = [
  {
    id: "ut-mir-1",
    map: "Mirage",
    side: "T",
    name: "CT Spawn Smoke from T-Spawn",
    type: "Smoke",
    target: "CT Spawn Crossing",
    description: "The most important smoke for any standard Mirage A Execute. Blocks CT sniper angle cleanly, allowing you to focus on stairs & jungle.",
    crosshairPlace: "Aim at the absolute center tip of the metallic antenna on top of the default building corner.",
    standSpot: "Stand flat against the T-spawn back wall, aligning the center of your player body with the garbage bin.",
    throwType: "Jump Throw"
  },
  {
    id: "ut-mir-2",
    map: "Mirage",
    side: "T",
    name: "A-Stairs Smoke from T-Spawn",
    type: "Smoke",
    target: "Stairs Pillar",
    description: "Denies A-stairs defenders from peaking the ramp or calling ramp push timing. Allows safe crossing into A site Tetris.",
    crosshairPlace: "Aim at the step-like ledge on the outer brick wall, third step up from the lower horizontal bar.",
    standSpot: "Squeeze into the wooden fence corner near T-ramp.",
    throwType: "Left Click"
  },
  {
    id: "ut-mir-3",
    map: "Mirage",
    side: "T",
    name: "Jungle & Connector Smoke",
    type: "Smoke",
    target: "Jungle / Connector Gap",
    description: "Perfect gap-closing smoke. Blocks deep connector and jungle sightlines. Throw in sync with Stairs and CT smokes.",
    crosshairPlace: "Aim directly at the bottom-left corner of the wooden window shutter on the distance building.",
    standSpot: "Stand in the middle of the second step of T-spawn brick staircase.",
    throwType: "Jump Throw"
  },
  {
    id: "ut-inf-1",
    map: "Inferno",
    side: "T",
    name: "Deep Arch Smoke from Banana",
    type: "Smoke",
    target: "Arch Side Path",
    description: "Splits CT defense entirely. Blocks quick rotations from A-site arch while your squad executes B or pushes Short.",
    crosshairPlace: "Aim at the topmost point of the hanging copper lantern on the left pillar structure.",
    standSpot: "Squeeze cleanly into the barrel corner at top of banana logs.",
    throwType: "Left Click"
  },
  {
    id: "ut-inf-2",
    map: "Inferno",
    side: "CT",
    name: "Banana Deep Retardant Molly",
    type: "Molly",
    target: "Deep Banana Entry",
    description: "Stops hard T rush strategies at the start of the match. Delays the attack so CT support can coordinate secondary flash blocks.",
    crosshairPlace: "Aim at the top leaf of the ivy hanging down from the CT banana stone archway.",
    standSpot: "Lean against the default stone brick of the CT sandbag alley.",
    throwType: "Run Throw"
  },
  {
    id: "ut-inf-3",
    map: "Inferno",
    side: "T",
    name: "Perfect CT Pop-Flash over Pit",
    type: "Flash",
    target: "Pit and Site Corners",
    description: "Blinds CT players holding standard Balcony, Pit, and Site angles without showing up on their radar screen.",
    crosshairPlace: "Aim at the yellow terracotta roof tile trim at the edge of the second balcony frame.",
    standSpot: "Press flat against the boiler door near A apartments.",
    throwType: "Left Click"
  },
  {
    id: "ut-d2-1",
    map: "Dust II",
    side: "T",
    name: "Xbox Smoke from T-Spawn Outside",
    type: "Smoke",
    target: "Mid Xbox Block",
    description: "Safely blocks Mid-doors visibility from CT snipers. Crucial for launching safe Short-A pushes or split-B maneuvers.",
    crosshairPlace: "Aim at the gap between the middle vertical wire and the first telephone pole beam.",
    standSpot: "Stand right on the gray pebble stripe in T Spawn outside stairs.",
    throwType: "Left Click"
  },
  {
    id: "ut-d2-2",
    map: "Dust II",
    side: "CT",
    name: "B-Tunnel Exit Rush Denial Frag",
    type: "Flash",
    target: "Upper Tunnels Exit",
    description: "Instant blind and stagger flash. Detonates exactly at upper tunnels mouth, blinding terrorists who just began their dash.",
    crosshairPlace: "Aim at the bottom right corner of the rusty metal mesh directly above the tunnel gate inside B.",
    standSpot: "Squeeze into the CT back-platform double boxes.",
    throwType: "Jump Throw"
  }
];
